--白条样本
use dmr_dev;
drop table if exists dmr_dev.bxy_ccard_label_0930_bt;
create table dmr_dev.bxy_ccard_label_0930_bt as 
select 
tab1.*, tab2.overdue_days overdue_days_30, tab2.overdue_amt overdue_amt_30,
tab2.cur_bal cur_bal_30,
case when tab1.overdue_days<=30 then 'M1'
    when tab1.overdue_days<=60 then 'M2'
    when tab1.overdue_days<=90 then 'M3'
    when tab1.overdue_days<=120 then 'M4'
    when tab1.overdue_days<=150 then 'M5'
    when tab1.overdue_days<=180 then 'M6'
    when tab1.overdue_days<=210 then 'M7'
    when tab1.overdue_days<=300 then '211-300'
    when tab1.overdue_days<=390 then '301-390'
    else '391+' end as ovd_stage,
case when tab2.overdue_days>=tab1.overdue_days+30 then 0 
when tab2.overdue_days is null then 1.1--30天后没有逾期天数，证明期间已还清，不升期为1
when tab1.overdue_days<=30 and tab2.overdue_days<30 then 1.2--M1循环
when tab1.overdue_days>30 and tab2.overdue_days<30 then 1.3--M2及以上还清历史但逾期1期
when tab2.overdue_days<tab1.overdue_days+30 then 1.4--30天内部分还款，不升期为1
else null end as target_sqr--否则升期，为0
from (
    select *
    from dmr_c.dmrc_cs_bt_overdays_amt_s_d
    where dt >= '2020-04-01'  and dt <= '2020-06-01'
    and overdue_days>0 and cur_bal>0) tab1
left join 
(
select *
from dmr_c.dmrc_cs_bt_overdays_amt_s_d 
where dt>='2020-04-01'
and overdue_days>0)tab2 on 
tab1.pin=tab2.pin and date_add(tab1.dt,30)=tab2.dt;

--金条样本
use dmr_dev;
drop table if exists dmr_dev.bxy_ccard_label_0930_jt;
create table dmr_dev.bxy_ccard_label_0930_jt as 
select 
tab1.*, tab2.overdue_days overdue_days_30, tab2.overdue_amt overdue_amt_30,
tab2.cur_bal cur_bal_30,
case when tab1.overdue_days<=30 then 'M1'
    when tab1.overdue_days<=60 then 'M2'
    when tab1.overdue_days<=90 then 'M3'
    when tab1.overdue_days<=120 then 'M4'
    when tab1.overdue_days<=150 then 'M5'
    when tab1.overdue_days<=180 then 'M6'
    when tab1.overdue_days<=210 then 'M7'
    when tab1.overdue_days<=300 then '211-300'
    when tab1.overdue_days<=390 then '301-390'
    else '391+' end as ovd_stage,
case when tab2.overdue_days>=tab1.overdue_days+30 then 0 
when tab2.overdue_days is null then 1.1--30天后没有逾期天数，证明期间已还清，不升期为1
when tab1.overdue_days<=30 and tab2.overdue_days<30 then 1.2--M1循环
when tab1.overdue_days>30 and tab2.overdue_days<30 then 1.3--M2及以上还清历史但逾期1期
when tab2.overdue_days<tab1.overdue_days+30 then 1.4--30天内部分还款，不升期为1
else null end as target_sqr--否则升期，为0
from (
    select *
    from dmr_c.dmrc_cs_jt_overdays_amt_s_d
    where dt >= '2020-04-01'  and dt <= '2020-06-01'
    and overdue_days>0 and cur_bal>0) tab1
left join 
(
select *
from dmr_c.dmrc_cs_jt_overdays_amt_s_d 
where dt>='2020-04-01'
and overdue_days>0)tab2 on 
tab1.pin=tab2.pin and date_add(tab1.dt,30)=tab2.dt;


--------汇总
use dmr_dev;
drop table if exists dmr_dev.bxy_ccard_label_0930_btjt;
create table dmr_dev.bxy_ccard_label_0930_btjt as 
    select z.*,
    case when tot_overdue_days<=30 then 'M1'
    when tot_overdue_days<=60 then 'M2'
    when tot_overdue_days<=90 then 'M3'
    when tot_overdue_days<=120 then 'M4'
    when tot_overdue_days<=150 then 'M5'
    when tot_overdue_days<=180 then 'M6'
    when tot_overdue_days<=210 then 'M7'
    when tot_overdue_days<=300 then '211-300'
    when tot_overdue_days<=390 then '301-390'    
    else '391+' end as tot_ovd_stage from
    (select c.pin, c.dt, a.target_sqr bt_target_sqr, b.target_sqr jt_target_sqr,
    a.ovd_stage bt_ovd_stage, b.ovd_stage jt_ovd_stage, 
    case when a.overdue_days is null and b.overdue_days is not null then b.overdue_days
    when a.overdue_days is not null and b.overdue_days is null then a.overdue_days
    else if(a.overdue_days>b.overdue_days,a.overdue_days,b.overdue_days) end tot_overdue_days
    from (
        select pin, dt from dmr_dev.bxy_ccard_label_0930_bt 
        union
        select pin, dt from dmr_dev.bxy_ccard_label_0930_jt
    ) c left join dmr_dev.bxy_ccard_label_0930_bt a 
    on c.pin=a.pin and c.dt=a.dt left join
    dmr_dev.bxy_ccard_label_0930_jt b 
    on c.pin=b.pin and c.dt=b.dt) z;


-- 每个用户随机保留当月1条样本
use dmr_dev;
drop table if exists dmr_dev.bxy_ccard_label_0930_btjt_one;
create table dmr_dev.bxy_ccard_label_0930_btjt_one as 
select t2.`(rand_seed)?+.+`
from
    (select t1.*,
    rank() over(partition by pin, substr(dt,1,7) order by rand()) as rand_seed
    from dmr_dev.bxy_ccard_label_0930_btjt t1) t2
where t2.rand_seed = 1;


--------随机分层抽样
--排除掉白条/金条标签不一致的个体
-----训练测试样本
use dmr_dev;
drop table if exists dmr_dev.bxy_ccard_label_0930_btjt_train_test;
create table dmr_dev.bxy_ccard_label_0930_btjt_train_test as 
select pin, dt, tot_target_sqr, ovd_type, tot_ovd_stage,
if(rand_seed>100000,'test','train') sample_label 
from
    (select 
        pin, dt,
    if(bt_target_sqr is null, floor(jt_target_sqr), floor(bt_target_sqr)) tot_target_sqr,
    rank() over(partition by tot_ovd_stage order by rand()) rand_seed,
    case when jt_target_sqr is null then 1
    when bt_target_sqr is null then 2
    else 3 end as ovd_type,
    tot_ovd_stage  
    from dmr_dev.bxy_ccard_label_0930_btjt_one
    where 
    (bt_target_sqr is null 
    or jt_target_sqr is null 
    or floor(bt_target_sqr)=floor(jt_target_sqr))
    and dt<'2020-06-01') a
where rand_seed<=120000;


-----跨时间样本 2020-06-01全量样本
-- use dmr_dev;
-- drop table if exists dmr_dev.bxy_ccard_label_0930_btjt_oot;
-- create table dmr_dev.bxy_ccard_label_0930_btjt_oot as 
-- select pin, dt, tot_target_sqr, ovd_type, tot_ovd_stage, 'oot' sample_label, jt_target_sqr,  bt_target_sqr, bt_ovd_stage, jt_ovd_stage,
--      date_sub(dt, 1) as dt_1, date_sub(trunc(date_sub(dt, 1),'MM'),1) as dt_30
-- from
--     (select pin, dt, 
--     if(bt_target_sqr is null, floor(jt_target_sqr), floor(bt_target_sqr)) tot_target_sqr,
--     case when jt_target_sqr is null then 1
--     when bt_target_sqr is null then 2
--     else 3 end as ovd_type,
--     tot_ovd_stage, jt_target_sqr, bt_target_sqr, bt_ovd_stage, jt_ovd_stage
--     from dmr_dev.bxy_ccard_label_0930_btjt_one
--     where 
--     (bt_target_sqr is null 
--     or jt_target_sqr is null 
--     or floor(bt_target_sqr)=floor(jt_target_sqr))
--     and dt = '2020-06-01') a;


--Select * From dmr_dev.zym_c_card_left_07_06;
