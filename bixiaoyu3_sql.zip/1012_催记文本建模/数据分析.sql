--******
--新旧Y_LABEL对比，取8.1 - 8.10的用户数据

--新标签
use dmr_dev;
drop table if exists dmr_dev.bxy_cuiji_text_modeling_labeltest1_bt;
create table dmr_dev.bxy_cuiji_text_modeling_labeltest1_bt as
Select 
    t1.pin, t1.dt,
    Case When sum(t2.amount) is not null Then 1 Else 0 End as clabel_t30
From 
    dmr_c.dmrc_model_t04_collect_c_score_v3_s_d t1 left join 
    dmr_c.dmrc_cs_repayment_a_d t2 on t1.pin = t2.pin and t2.paydate >= t1.dt and t2.paydate <= date_add(t1.dt, 30)
Where 
    t1.dt >= '2020-08-01' and t1.dt <= '2020-08-10' and 
    (bt_cur_overdue_days > 0 and bt_cur_bal > 0)
Group By 
    t1.pin, t1.dt;

use dmr_dev;
drop table if exists dmr_dev.bxy_cuiji_text_modeling_labeltest1_jt;
create table dmr_dev.bxy_cuiji_text_modeling_labeltest1_jt as
Select 
    t1.pin, t1.dt,
    Case When sum(t2.amount) is not null Then 1 Else 0 End as clabel_t30
From 
    dmr_c.dmrc_model_t04_collect_c_score_v3_s_d t1 left join 
    dmr_c.dmrc_cs_repayment_a_d t2 on t1.pin = t2.pin and t2.paydate >= t1.dt and t2.paydate <= date_add(t1.dt, 30)
Where 
    t1.dt >= '2020-08-01' and t1.dt <= '2020-08-10' and 
    (jt_cur_overdue_days > 0 and jt_cur_bal > 0)
Group By 
    t1.pin, t1.dt;

Select * From dmr_dev.bxy_cuiji_text_modeling_labeltest1_bt;
Select * From dmr_dev.bxy_cuiji_text_modeling_labeltest1_jt;

--旧标签
use dmr_dev;
drop table if exists dmr_dev.bxy_cuiji_text_modeling_labeltest2_bt;
create table dmr_dev.bxy_cuiji_text_modeling_labeltest2_bt as
select 
tab1.pin, tab1.dt,
min(case when tab2.overdue_days>=tab1.overdue_days+30 then 0 
when tab2.overdue_days is null then 1--30天后没有逾期天数，证明期间已还清，不升期为1
when tab1.overdue_days<=30 and tab2.overdue_days<30 then 1--M1循环
when tab1.overdue_days>30 and tab2.overdue_days<30 then 1--M2及以上还清历史但逾期1期
when tab2.overdue_days<tab1.overdue_days+30 then 1--30天内部分还款，不升期为1
else 0 end) as target_sqr--否则升期，为0
from (
    select *
    from dmr_c.dmrc_cs_bt_overdays_amt_s_d
    where dt >= '2020-08-01'  and dt <= '2020-08-10'
    and overdue_days>0 and cur_bal>0) tab1
left join 
(
select *
from dmr_c.dmrc_cs_bt_overdays_amt_s_d 
where dt>='2020-08-01'
and overdue_days>0)tab2 on tab1.pin=tab2.pin and date_add(tab1.dt,30)=tab2.dt
group by tab1.pin, tab1.dt;

use dmr_dev;
drop table if exists dmr_dev.bxy_cuiji_text_modeling_labeltest2_jt;
create table dmr_dev.bxy_cuiji_text_modeling_labeltest2_jt as
select 
tab1.pin, tab1.dt,
min(case when tab2.overdue_days>=tab1.overdue_days+30 then 0 
when tab2.overdue_days is null then 1--30天后没有逾期天数，证明期间已还清，不升期为1
when tab1.overdue_days<=30 and tab2.overdue_days<30 then 1--M1循环
when tab1.overdue_days>30 and tab2.overdue_days<30 then 1--M2及以上还清历史但逾期1期
when tab2.overdue_days<tab1.overdue_days+30 then 1--30天内部分还款，不升期为1
else 0 end) as target_sqr--否则升期，为0
from (
    select *
    from dmr_c.dmrc_cs_jt_overdays_amt_s_d
    where dt >= '2020-08-01'  and dt <= '2020-08-10'
    and overdue_days>0 and cur_bal>0) tab1
left join 
(
select *
from dmr_c.dmrc_cs_jt_overdays_amt_s_d 
where dt>='2020-08-01'
and overdue_days>0)tab2 on tab1.pin=tab2.pin and date_add(tab1.dt,30)=tab2.dt
group by tab1.pin, tab1.dt;

Select * From dmr_dev.bxy_cuiji_text_modeling_labeltest2_bt;
Select * From dmr_dev.bxy_cuiji_text_modeling_labeltest2_jt;

--新旧对比 
use dmr_dev;
drop table if exists dmr_dev.bxy_cuiji_text_modeling_labeltest_compare_bt;
create table dmr_dev.bxy_cuiji_text_modeling_labeltest_compare_bt as
Select 
    old.pin as pin_old, new.pin as pin_new,
    old.dt as dt_old, new.dt as dt_new,
    old.target_sqr as label_old, new.clabel_t30 as label_new
From 
    dmr_dev.bxy_cuiji_text_modeling_labeltest2_bt old full outer join 
    dmr_dev.bxy_cuiji_text_modeling_labeltest1_bt new on old.dt = new.dt and old.pin = new.pin;

use dmr_dev;
drop table if exists dmr_dev.bxy_cuiji_text_modeling_labeltest_compare_jt;
create table dmr_dev.bxy_cuiji_text_modeling_labeltest_compare_jt as
Select 
    old.pin as pin_old, new.pin as pin_new,
    old.dt as dt_old, new.dt as dt_new,
    old.target_sqr as label_old, new.clabel_t30 as label_new
From 
    dmr_dev.bxy_cuiji_text_modeling_labeltest2_jt old full outer join 
    dmr_dev.bxy_cuiji_text_modeling_labeltest1_jt new on old.dt = new.dt and old.pin = new.pin;

Select * From dmr_dev.bxy_cuiji_text_modeling_labeltest_compare_bt;
Select * From dmr_dev.bxy_cuiji_text_modeling_labeltest_compare_jt;

--统计
Select 
    sum(abs(label_new - label_old)), count(*)
From 
    dmr_dev.bxy_cuiji_text_modeling_labeltest_compare_bt
Where 
    dt_old is not null and dt_new is not null;
    
Select 
    sum(abs(label_new - label_old)), count(*)
From 
    dmr_dev.bxy_cuiji_text_modeling_labeltest_compare_jt
Where 
    dt_old is not null and dt_new is not null; 

--******
--新旧Y_LABEL对比，取8.1 - 8.10的用户数据













