Select * from dmr_c.dmrc_model_t04_collect_c_score_v3_s_d;
Select * From dmr_c.dmrc_cs_repayment_a_d;
Select * From odm.odm_risk_qt_case_info_i_d;

--******人工对话
--只抽取9、10月的
use dmr_dev;
drop table if exists dmr_dev.bxy_cuiji_text_modeling_human_sample1;
create table dmr_dev.bxy_cuiji_text_modeling_human_sample1 as
Select 
    t1.pin, t1.dt, t1.org_score, t1.tot_overdue_days
From 
    (Select
        pin, dt, org_score, 
        (case when bt_cur_overdue_days is null and jt_cur_overdue_days is not null then jt_cur_overdue_days
        when bt_cur_overdue_days is not null and jt_cur_overdue_days is null then bt_cur_overdue_days
        else if(bt_cur_overdue_days>jt_cur_overdue_days,bt_cur_overdue_days,jt_cur_overdue_days) end) tot_overdue_days
    From 
        dmr_c.dmrc_model_t04_collect_c_score_v3_s_d) t1
Where 
    substring(t1.dt, 1, 7) in ('2020-09', '2020-10')
Group By 
    t1.pin, t1.dt, t1.org_score, t1.tot_overdue_days;

--C卡分+30日还款标签
use dmr_dev;
drop table if exists dmr_dev.bxy_cuiji_text_modeling_human_sample1_1;
create table dmr_dev.bxy_cuiji_text_modeling_human_sample1_1 as
Select 
    t1.pin, t1.dt, t1.org_score, t1.tot_overdue_days,
    (Case When sum(t2.amount) is not null Then 1 Else 0 End) as clabel_t30
From 
    dmr_dev.bxy_cuiji_text_modeling_human_sample1 t1 left join 
    dmr_c.dmrc_cs_repayment_a_d t2 on t1.pin = t2.pin and t2.paydate >= t1.dt and t2.paydate <= date_add(t1.dt, 30)
Group By 
    t1.pin, t1.dt, t1.org_score, t1.tot_overdue_days;

--C卡分+10日还款标签
use dmr_dev;
drop table if exists dmr_dev.bxy_cuiji_text_modeling_human_sample1_2;
create table dmr_dev.bxy_cuiji_text_modeling_human_sample1_2 as
Select 
    t1.pin, t1.dt, t1.org_score, t1.tot_overdue_days, t1.clabel_t30,
    (Case When sum(t2.amount) is not null Then 1 Else 0 End) as clabel_t10
From 
    dmr_dev.bxy_cuiji_text_modeling_human_sample1_1 t1 left join 
    dmr_c.dmrc_cs_repayment_a_d t2 on t1.pin = t2.pin and t2.paydate >= t1.dt and t2.paydate <= date_add(t1.dt, 10)
Group By 
    t1.pin, t1.dt, t1.org_score, t1.tot_overdue_days, t1.clabel_t30;

--C卡分+3日还款标签
use dmr_dev;
drop table if exists dmr_dev.bxy_cuiji_text_modeling_human_sample1_3;
create table dmr_dev.bxy_cuiji_text_modeling_human_sample1_3 as
Select 
    t1.pin, t1.dt, t1.org_score, t1.tot_overdue_days, t1.clabel_t30, t1.clabel_t10,
    (Case When sum(t2.amount) is not null Then 1 Else 0 End) as clabel_t3
From 
    dmr_dev.bxy_cuiji_text_modeling_human_sample1_2 t1 left join 
    dmr_c.dmrc_cs_repayment_a_d t2 on t1.pin = t2.pin and t2.paydate >= t1.dt and t2.paydate <= date_add(t1.dt, 3)
Group By 
    t1.pin, t1.dt, t1.org_score, t1.tot_overdue_days, t1.clabel_t30, t1.clabel_t10;

--对话文本+C卡分+30日还款标签,只抽取9、10月的
use dmr_dev;
drop table if exists dmr_dev.bxy_cuiji_text_modeling_human_sample2;
create table dmr_dev.bxy_cuiji_text_modeling_human_sample2 as
Select
    t1.cust_key as pin, t2.dt, t2.org_score, t2.clabel_t30, t2.clabel_t10, t2.clabel_t3,
    (Case when tot_overdue_days<=30 then 'M1'
    when tot_overdue_days<=60 then 'M2'
    when tot_overdue_days<=90 then 'M3'
    when tot_overdue_days<=120 then 'M4'
    when tot_overdue_days<=150 then 'M5'
    when tot_overdue_days<=180 then 'M6'
    when tot_overdue_days<=210 then 'M7'
    when tot_overdue_days<=300 then '211-300'
    when tot_overdue_days<=390 then '301-390'    
    else '391+' end) as tot_ovd_stage,
    get_json_object(t1.qt_voice_text, '$.duration')/1000 as duration,
    get_json_object(t1.qt_voice_text, '$.sentenceList') as sentenceList
From 
    odm.odm_risk_qt_case_info_i_d t1 left join 
    dmr_dev.bxy_cuiji_text_modeling_human_sample1_3 t2 on t1.cust_key = t2.pin and substring(t1.urge_time, 1, 10) = t2.dt
Where 
    substring(t1.urge_time, 1, 7) in ('2020-09', '2020-10') and
    get_json_object(t1.qt_voice_text, '$.duration') > 0 and 
    clabel_t30 is not null and get_json_object(t1.qt_voice_text, '$.sentenceList') is not null;
    
    
--C卡特征拼接
use dmr_dev;
drop table if exists dmr_dev.bxy_cuiji_text_modeling_human_sample2_c;
create table dmr_dev.bxy_cuiji_text_modeling_human_sample2_c as
Select
    t1.*, t2.`(pin|dt)?+.+`
From 
    dmr_dev.bxy_cuiji_text_modeling_human_sample2 t1 left join 
    (Select 
        pin, dt,
        cv2btf11166,bt_cur_overdue_days,bt_cur_bal,cv3f7,cv2jtf1407,cv2btf11161,cv3f4086,bt_max_overdue_days,cv2btf7988,cv3f3881,cv3f3889,cv2jtf987,cv3f3863,
        cv3f3965,cv2btf10802,cv3f25,cv2btf11150,cv3f6,cv2btf11163,cv2btf11158,cv2btf11177,cv3f9,cv3f3895,device_brand_cnt,cv2btf11167,cv2jtf379,cv2jtf218,cv3f3991,
        cv3f3908,cv3f3803,cv3f758,cv2btf11170,cv3f3905,cv2jtf128,cv3f607,cv2btf11160,cv2btf11006,cv3f3997,cv2btf10905,cv3f757,cv3f4100,cv2btf10931,
        cv2btf10854,cv3f721,cv3f3967,cv2jtf118,cv2btf10858,cv3f4087,cv3f3977,cv3f3907
    From 
        dmr_c.dmrc_model_t04_collect_c_score_v3_features_s_d
    Where 
        dt >= '2020-09-01' and dt <= '2020-11-02') t2 on date_add(t1.dt, 1) = t2.dt and t1.pin = t2.pin;


--9月用作训练集、验证集
use dmr_dev;
drop table if exists dmr_dev.bxy_cuiji_text_modeling_human_sample2_train;
create table dmr_dev.bxy_cuiji_text_modeling_human_sample2_train as
Select 
    *
From 
    (Select 
        *, rank() over(partition by tot_ovd_stage order by rand()) as ra
    From 
        dmr_dev.bxy_cuiji_text_modeling_human_sample2_c
    Where 
        substring(dt, 1, 7) = '2020-09') tmp;

--10月用作测试集
use dmr_dev;
drop table if exists dmr_dev.bxy_cuiji_text_modeling_human_sample2_test;
create table dmr_dev.bxy_cuiji_text_modeling_human_sample2_test as
Select 
    *
From 
    (Select 
        *, rank() over(partition by tot_ovd_stage order by rand()) as ra
    From 
        dmr_dev.bxy_cuiji_text_modeling_human_sample2_c
    Where 
        substring(dt, 1, 7) = '2020-10') tmp;

Select * From dmr_dev.bxy_cuiji_text_modeling_human_sample2_train;
Select * From dmr_dev.bxy_cuiji_text_modeling_human_sample2_test;
Select Count(*) From dmr_dev.bxy_cuiji_text_modeling_human_sample2_train;
Select Count(*) From dmr_dev.bxy_cuiji_text_modeling_human_sample2_test;


--9月用户级分析
--用户量对比通话量
select 
    dt, count(DISTINCT pin), count(DISTINCT qt_id)
from 
    dmr_c.dmrc_model_t04_collect_overdue_dialogue_i_d 
where 
    substring(dt, 1, 7) = '2020-09' and call_type = 'human'
group by 
    dt 
order by 
    dt DESC;
    
select 
    t1.dt, count(DISTINCT t1.pin), count(DISTINCT t2.pin)
from 
    dmr_dev.bxy_cuiji_text_modeling_human_sample2_train t1 left join 
    dmr_dev.bxy_cuiji_text_modeling_human_sample2_train t2 on t1.pin = t2.pin and date_sub(t1.dt, 1) >= t2.dt and date_sub(t1.dt, 3) <= t2.dt
group by 
    t1.dt;

select 
    t1.dt, count(DISTINCT t1.pin), count(DISTINCT t2.pin)
from 
    dmr_dev.bxy_cuiji_text_modeling_human_sample2_train t1 left join 
    dmr_dev.bxy_cuiji_text_modeling_human_sample2_train t2 on t1.pin = t2.pin and date_sub(t1.dt, 1) >= t2.dt and date_sub(t1.dt, 10) <= t2.dt
group by 
    t1.dt;















