desc dmr_c.dmrc_model_t04_collect_bert_textmodel_raw_data_i_d;
show partitions dmr_c.dmrc_model_t04_collect_bert_textmodel_raw_data_i_d;
Select * From dmr_c.dmrc_model_t04_collect_bert_textmodel_raw_data_i_d where dt = '2020-09-01';
Select Count(*) From dmr_c.dmrc_model_t04_collect_bert_textmodel_raw_data_i_d where dt = '2020-09-01';

--空值统计
Select 
    dt, 
    count(Case When duration >= 15 then 1 Else null End),
    count(sentencelist), 
    count(*)
From 
    dmr_c.dmrc_model_t04_collect_bert_textmodel_raw_data_i_d
Group By 
    dt;

desc dmr_c.dmrc_model_t04_collect_bert_textmodel_score_i_d;
show partitions dmr_c.dmrc_model_t04_collect_bert_textmodel_score_i_d;
Select * From dmr_c.dmrc_model_t04_collect_bert_textmodel_score_i_d;