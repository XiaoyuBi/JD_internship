Select * From dmr_dev.bxy_temp_qt_intent_sequence;
Select * From odm.odm_risk_qt_case_info_i_d;

--qt数据+用户pin+C卡分数
use dmr_dev;
drop table if exists dmr_dev.bxy_cuiji_intent_modeling_sample1;
create table dmr_dev.bxy_cuiji_intent_modeling_sample1 as
Select 
    t1.*, t2.pin, t2.dt, t2.duration, t2.sentenceList, t3.org_score, t3.tot_overdue_days
From 
    dmr_dev.bxy_temp_qt_intent_sequence t1 left join 
    (Select 
        qt_id, cust_key as pin, dt, 
        get_json_object(qt_voice_text, '$.duration')/1000 as duration,
        get_json_object(qt_voice_text, '$.sentenceList') as sentenceList
    From 
        odm.odm_risk_qt_case_info_i_d) t2 on t1.qt_id = t2.qt_id left join 
    (Select
        pin, dt, org_score, 
        (case when bt_cur_overdue_days is null and jt_cur_overdue_days is not null then jt_cur_overdue_days
        when bt_cur_overdue_days is not null and jt_cur_overdue_days is null then bt_cur_overdue_days
        else if(bt_cur_overdue_days>jt_cur_overdue_days,bt_cur_overdue_days,jt_cur_overdue_days) end) tot_overdue_days
    From 
        dmr_c.dmrc_model_t04_collect_c_score_v3_s_d) t3 on t2.pin = t3.pin and t2.dt = t3.dt;

Select * From dmr_dev.bxy_cuiji_intent_modeling_sample1;
Select count(*) From dmr_dev.bxy_cuiji_intent_modeling_sample1;

--拼接t+30标签
use dmr_dev;
drop table if exists dmr_dev.bxy_cuiji_intent_modeling_sample2_1;
create table dmr_dev.bxy_cuiji_intent_modeling_sample2_1 as
Select 
    t1.pin, t1.dt, t1.intent_set, t1.org_score, t1.tot_overdue_days, t1.duration, t1.sentenceList,
    (Case When sum(t2.amount) is not null Then 1 Else 0 End) as clabel_t30
From 
    dmr_dev.bxy_cuiji_intent_modeling_sample1 t1 left join 
    dmr_c.dmrc_cs_repayment_a_d t2 on t1.pin = t2.pin and t2.paydate >= t1.dt and t2.paydate <= date_add(t1.dt, 30)
Group By 
    t1.pin, t1.dt, t1.intent_set, t1.org_score, t1.tot_overdue_days, t1.duration, t1.sentenceList;

Select * From dmr_dev.bxy_cuiji_intent_modeling_sample2_1;
Select count(*) From dmr_dev.bxy_cuiji_intent_modeling_sample2_1;

--拼接t+3标签
use dmr_dev;
drop table if exists dmr_dev.bxy_cuiji_intent_modeling_sample2_2;
create table dmr_dev.bxy_cuiji_intent_modeling_sample2_2 as
Select 
    t1.pin, t1.dt, t1.intent_set, t1.org_score, t1.tot_overdue_days, t1.duration, t1.sentenceList, t1.clabel_t30,
    (Case When sum(t2.amount) is not null Then 1 Else 0 End) as clabel_t3
From 
    dmr_dev.bxy_cuiji_intent_modeling_sample2_1 t1 left join 
    dmr_c.dmrc_cs_repayment_a_d t2 on t1.pin = t2.pin and t2.paydate >= t1.dt and t2.paydate <= date_add(t1.dt, 3)
Group By 
    t1.pin, t1.dt, t1.intent_set, t1.org_score, t1.tot_overdue_days, t1.duration, t1.sentenceList, t1.clabel_t30;

Select * From dmr_dev.bxy_cuiji_intent_modeling_sample2_2;
Select count(*) From dmr_dev.bxy_cuiji_intent_modeling_sample2_2;

--拼接C卡特征
use dmr_dev;
drop table if exists dmr_dev.bxy_cuiji_intent_modeling_sample2_3;
create table dmr_dev.bxy_cuiji_intent_modeling_sample2_3 as
Select 
    t1.pin, t1.dt, t1.intent_set, t1.sentenceList, t1.duration, t1.clabel_t30, t1.clabel_t3, t1.org_score,
    (Case when tot_overdue_days<=30 then 'M1'
    when tot_overdue_days<=60 then 'M2'
    when tot_overdue_days<=90 then 'M3'
    when tot_overdue_days<=120 then 'M4'
    when tot_overdue_days<=150 then 'M5'
    when tot_overdue_days<=180 then 'M6'
    when tot_overdue_days<=210 then 'M7'
    when tot_overdue_days<=300 then '211-300'
    when tot_overdue_days<=390 then '301-390'    
    else '391+' end) as tot_ovd_stage,
    t2.`(pin|dt)?+.+`
From 
    dmr_dev.bxy_cuiji_intent_modeling_sample2_2 t1 left join 
    (Select 
        pin, dt,
        cv2btf11166,bt_cur_overdue_days,bt_cur_bal,cv3f7,cv2jtf1407,cv2btf11161,cv3f4086,bt_max_overdue_days,cv2btf7988,cv3f3881,cv3f3889,cv2jtf987,cv3f3863,
        cv3f3965,cv2btf10802,cv3f25,cv2btf11150,cv3f6,cv2btf11163,cv2btf11158,cv2btf11177,cv3f9,cv3f3895,device_brand_cnt,cv2btf11167,cv2jtf379,cv2jtf218,cv3f3991,
        cv3f3908,cv3f3803,cv3f758,cv2btf11170,cv3f3905,cv2jtf128,cv3f607,cv2btf11160,cv2btf11006,cv3f3997,cv2btf10905,cv3f757,cv3f4100,cv2btf10931,
        cv2btf10854,cv3f721,cv3f3967,cv2jtf118,cv2btf10858,cv3f4087,cv3f3977,cv3f3907
    From 
        dmr_c.dmrc_model_t04_collect_c_score_v3_features_s_d) t2 on date_add(t1.dt, 1) = t2.dt and t1.pin = t2.pin;

Select * From dmr_dev.bxy_cuiji_intent_modeling_sample2_3;
Select count(*) From dmr_dev.bxy_cuiji_intent_modeling_sample2_3;










