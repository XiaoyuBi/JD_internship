--Select dt From dmr_dev.tmp_jt_loan_paid_t36 Group by dt;
--show partitions dmr_c.dmrc_model_t04_collect_c_score_v3_features_s_d;

--Select * From dmr_dev.tmp_jt_loan_paid_t36;

set mapreduce.map.memory.mb=8192; 
set mapreduce.map.java.opts=-Xmx7200m;

--****************************
---- 金条

--添加逾期分组
use dmr_dev;
drop table if exists dmr_dev.bxy_tmp_jt_loan_paid_t36_1;
create table dmr_dev.bxy_tmp_jt_loan_paid_t36_1 as
Select 
    *,
    if(ceil(curr_over_days/30) <= 36, ceil(curr_over_days/30), 'M36+') as ovd_stage
From 
    dmr_dev.tmp_jt_loan_paid_t36
Where
    curr_over_days > 30 and
    dt in ('2018-12-31', '2019-01-31', '2019-02-28', '2019-03-31', '2019-04-30', '2019-05-31', '2019-06-30', '2019-07-31', '2019-08-31', '2019-09-30', 
    '2019-10-31', '2019-11-30', '2019-12-31', '2020-01-31', '2020-02-29', '2020-03-31', '2020-04-30', '2020-05-31', '2020-06-30', '2020-07-31', '2020-08-31');

--Select  * From dmr_dev.bxy_tmp_jt_loan_paid_t36_1;
--Select Count(*) From dmr_dev.bxy_tmp_jt_loan_paid_t36_1;

--抽 样 (订单级)
use dmr_dev;
drop table if exists dmr_dev.bxy_tmp_jt_loan_paid_t36_sample;
create table dmr_dev.bxy_tmp_jt_loan_paid_t36_sample as
select
  dt, user_pin, loan_id
from
    (select
      dt, user_pin, loan_id,
      row_number() over(partition by dt, ovd_stage order by rand()) row_id
    from
      dmr_dev.bxy_tmp_jt_loan_paid_t36_1) as a
where
  row_id <= 10000
group by
  dt, user_pin, loan_id;

--Select Count(*) From dmr_dev.bxy_tmp_jt_loan_paid_t36_sample;

--匹配抽样样本
use dmr_dev;
drop table if exists dmr_dev.bxy_tmp_jt_loan_paid_t36_2;
create table dmr_dev.bxy_tmp_jt_loan_paid_t36_2 as
select
  t2.*
from
  dmr_dev.bxy_tmp_jt_loan_paid_t36_sample t1 left join dmr_dev.bxy_tmp_jt_loan_paid_t36_1 t2 on 
  t1.user_pin = t2.user_pin and t1.loan_id = t2.loan_id and t1.dt = t2.dt;

--Select Count(*) From dmr_dev.bxy_tmp_jt_loan_paid_t36_2;

--拼接C卡V3特征（重要度靠前特征）
use dmr_dev;
drop table if exists dmr_dev.bxy_tmp_jt_loan_paid_t36_c_card_feature;
create table dmr_dev.bxy_tmp_jt_loan_paid_t36_c_card_feature as
select
  t1.*,  t2.`(pin|dt)?+.+`
from
  dmr_dev.bxy_tmp_jt_loan_paid_t36_2 t1 left join 
  (select
   pin, dt, cv2btf11166,	cv3f7,	cv2jtf1407,	cv3f4086,	cv2btf11161,	cv2btf7988,	cv2jtf987,	cv3f3889,	cv2btf11150,	cv3f3863,	cv3f3881,	cv3f3895,	cv2btf10802,	device_brand_cnt,	cv3f3905,	cv2jtf218,	cv3f3965,	cv3f9,	cv2btf11158,	cv2btf11163,	cv3f3803,	cv2jtf379,	cv3f6,	cv2btf11177,	cv2jtf24,	cv3f3991,	cv3f3907,	cv3f758,	cv2btf11137,	cv2btf10955,	cv3f3823,	cv3f4100,	cv3f777,	cv2btf11167,	cv3f1537,	cv3f3983,	cv2jtf128,	cv3f3918,	cv3f3967,	cv3f877,	cv2jtf1064,	cv3f4087,	cv3f619,	scf632,	cv2btf10858,	cv2jtf83,	cv3f1538,	cv3f3908,	cv3f607,	cv3f757,	cv2btf10264,	cv2btf10822,	cv3f715,	cv2btf10758,	cv2btf10980,	cv2btf11117,	cv2btf9973,	cv2jtf1728,	cv3f3875,	cv3f4084,	cv3f4101,	cv3f615,	cv3f721,	cv2btf10736,	cv2jtf50,	cv3f3843,	cv3f3997,	cv3f625,	cv3f657,	cv2btf10854,	cv2btf11160,	cv2btf9938,	cv3f1505,	cv2btf11192,	cv2btf4475,	cv2btf9624,	cv3f1442,	cv3f639,	cv3f647,	cv3f751,	scf349,	scf356,	cv2btf10001
   from
     dmr_c.dmrc_model_t04_collect_c_score_v3_features_s_d) t2 on date_add(t1.dt, 1) = t2.dt and t1.user_pin = t2.pin;

--Select Count(*) From dmr_dev.bxy_tmp_jt_loan_paid_t36_c_card_feature;
--Select * From dmr_dev.bxy_tmp_jt_loan_paid_t36_c_card_feature;

--分组样本量验证
Select dt, ovd_stage, count(*) From dmr_dev.bxy_tmp_jt_loan_paid_t36_c_card_feature group by dt, ovd_stage order by dt, ovd_stage;



set mapreduce.map.memory.mb=8192; 
set mapreduce.map.java.opts=-Xmx7200m;

--****************************
---- 白条（不含取现）

--添加逾期分组
use dmr_dev;
drop table if exists dmr_dev.bxy_tmp_bt_loan_paid_t36_1;
create table dmr_dev.bxy_tmp_bt_loan_paid_t36_1 as
Select 
    *,
    if(ceil(overdue_days/30) <= 36, ceil(overdue_days/30), 'M36+') as ovd_stage
From 
    dmr_dev.tmp_bt_loan_paid_t36
Where
    overdue_days > 30 and
    dt in ('2018-12-31', '2019-01-31', '2019-02-28', '2019-03-31', '2019-04-30', '2019-05-31', '2019-06-30', '2019-07-31', '2019-08-31', '2019-09-30', 
    '2019-10-31', '2019-11-30', '2019-12-31', '2020-01-31', '2020-02-29', '2020-03-31', '2020-04-30', '2020-05-31', '2020-06-30', '2020-07-31', '2020-08-31');

--Select * From dmr_dev.bxy_tmp_bt_loan_paid_t36_1;
--Select Count(*) From dmr_dev.bxy_tmp_bt_loan_paid_t36_1;

--抽 样 (订单级)
use dmr_dev;
drop table if exists dmr_dev.bxy_tmp_bt_loan_paid_t36_sample;
create table dmr_dev.bxy_tmp_bt_loan_paid_t36_sample as
select
  dt, pin, orderid
from
    (select
      dt, pin, orderid,
      row_number() over(partition by dt, ovd_stage order by rand()) row_id
    from
      dmr_dev.bxy_tmp_bt_loan_paid_t36_1) as a
where
  row_id <= 10000
group by
  dt, pin, orderid;

--Select Count(*) From dmr_dev.bxy_tmp_bt_loan_paid_t36_sample;

--匹配抽样样本
use dmr_dev;
drop table if exists dmr_dev.bxy_tmp_bt_loan_paid_t36_2;
create table dmr_dev.bxy_tmp_bt_loan_paid_t36_2 as
select
  t2.*
from
  dmr_dev.bxy_tmp_bt_loan_paid_t36_sample t1 left join dmr_dev.bxy_tmp_bt_loan_paid_t36_1 t2 on 
  t1.pin = t2.pin and t1.orderid = t2.orderid and t1.dt = t2.dt;

--Select Count(*) From dmr_dev.bxy_tmp_bt_loan_paid_t36_2;

--拼接C卡V3特征（重要度靠前特征）
use dmr_dev;
drop table if exists dmr_dev.bxy_tmp_bt_loan_paid_t36_c_card_feature;
create table dmr_dev.bxy_tmp_bt_loan_paid_t36_c_card_feature as
select
  t1.*,  t2.`(pin|dt)?+.+`
from
  dmr_dev.bxy_tmp_bt_loan_paid_t36_2 t1 left join 
  (select
   pin, dt, cv2btf11166,	cv3f7,	cv2jtf1407,	cv3f4086,	cv2btf11161,	cv2btf7988,	cv2jtf987,	cv3f3889,	cv2btf11150,	cv3f3863,	cv3f3881,	cv3f3895,	cv2btf10802,	device_brand_cnt,	cv3f3905,	cv2jtf218,	cv3f3965,	cv3f9,	cv2btf11158,	cv2btf11163,	cv3f3803,	cv2jtf379,	cv3f6,	cv2btf11177,	cv2jtf24,	cv3f3991,	cv3f3907,	cv3f758,	cv2btf11137,	cv2btf10955,	cv3f3823,	cv3f4100,	cv3f777,	cv2btf11167,	cv3f1537,	cv3f3983,	cv2jtf128,	cv3f3918,	cv3f3967,	cv3f877,	cv2jtf1064,	cv3f4087,	cv3f619,	scf632,	cv2btf10858,	cv2jtf83,	cv3f1538,	cv3f3908,	cv3f607,	cv3f757,	cv2btf10264,	cv2btf10822,	cv3f715,	cv2btf10758,	cv2btf10980,	cv2btf11117,	cv2btf9973,	cv2jtf1728,	cv3f3875,	cv3f4084,	cv3f4101,	cv3f615,	cv3f721,	cv2btf10736,	cv2jtf50,	cv3f3843,	cv3f3997,	cv3f625,	cv3f657,	cv2btf10854,	cv2btf11160,	cv2btf9938,	cv3f1505,	cv2btf11192,	cv2btf4475,	cv2btf9624,	cv3f1442,	cv3f639,	cv3f647,	cv3f751,	scf349,	scf356,	cv2btf10001
   from
     dmr_c.dmrc_model_t04_collect_c_score_v3_features_s_d) t2 on date_add(t1.dt, 1) = t2.dt and t1.pin = t2.pin;

--Select Count(*) From dmr_dev.bxy_tmp_bt_loan_paid_t36_c_card_feature;
--Select * From dmr_dev.bxy_tmp_bt_loan_paid_t36_c_card_feature;

--分组样本量验证
Select dt, ovd_stage, count(*) From dmr_dev.bxy_tmp_bt_loan_paid_t36_c_card_feature group by dt, ovd_stage order by dt, ovd_stage;


set mapreduce.map.memory.mb=8192; 
set mapreduce.map.java.opts=-Xmx7200m;

--****************************
---- 白条取现

--添加逾期分组
use dmr_dev;
drop table if exists dmr_dev.bxy_tmp_btqx_loan_paid_t36_1;
create table dmr_dev.bxy_tmp_btqx_loan_paid_t36_1 as
Select 
    *,
    if(ceil(overdue_days/30) <= 36, ceil(overdue_days/30), 'M36+') as ovd_stage
From 
    dmr_dev.tmp_btqx_loan_paid_t36
Where
    overdue_days > 30 and
    dt in ('2018-12-31', '2019-01-31', '2019-02-28', '2019-03-31', '2019-04-30', '2019-05-31', '2019-06-30', '2019-07-31', '2019-08-31', '2019-09-30', 
    '2019-10-31', '2019-11-30', '2019-12-31', '2020-01-31', '2020-02-29', '2020-03-31', '2020-04-30', '2020-05-31', '2020-06-30', '2020-07-31', '2020-08-31');

--Select * From dmr_dev.bxy_tmp_btqx_loan_paid_t36_1;
--Select Count(*) From dmr_dev.bxy_tmp_btqx_loan_paid_t36_1;

--抽 样 (订单级)
use dmr_dev;
drop table if exists dmr_dev.bxy_tmp_btqx_loan_paid_t36_sample;
create table dmr_dev.bxy_tmp_btqx_loan_paid_t36_sample as
select
  dt, pin, orderid
from
    (select
      dt, pin, orderid,
      row_number() over(partition by dt, ovd_stage order by rand()) row_id
    from
      dmr_dev.bxy_tmp_btqx_loan_paid_t36_1) as a
where
  row_id <= 10000
group by
  dt, pin, orderid;

--Select Count(*) From dmr_dev.bxy_tmp_btqx_loan_paid_t36_sample;

--匹配抽样样本
use dmr_dev;
drop table if exists dmr_dev.bxy_tmp_btqx_loan_paid_t36_2;
create table dmr_dev.bxy_tmp_btqx_loan_paid_t36_2 as
select
  t2.*
from
  dmr_dev.bxy_tmp_btqx_loan_paid_t36_sample t1 left join dmr_dev.bxy_tmp_btqx_loan_paid_t36_1 t2 on 
  t1.pin = t2.pin and t1.orderid = t2.orderid and t1.dt = t2.dt;

--Select Count(*) From dmr_dev.bxy_tmp_btqx_loan_paid_t36_2;

--拼接C卡V3特征（重要度靠前特征）
use dmr_dev;
drop table if exists dmr_dev.bxy_tmp_btqx_loan_paid_t36_c_card_feature;
create table dmr_dev.bxy_tmp_btqx_loan_paid_t36_c_card_feature as
select
  t1.*,  t2.`(pin|dt)?+.+`
from
  dmr_dev.bxy_tmp_btqx_loan_paid_t36_2 t1 left join 
  (select
   pin, dt, cv2btf11166,	cv3f7,	cv2jtf1407,	cv3f4086,	cv2btf11161,	cv2btf7988,	cv2jtf987,	cv3f3889,	cv2btf11150,	cv3f3863,	cv3f3881,	cv3f3895,	cv2btf10802,	device_brand_cnt,	cv3f3905,	cv2jtf218,	cv3f3965,	cv3f9,	cv2btf11158,	cv2btf11163,	cv3f3803,	cv2jtf379,	cv3f6,	cv2btf11177,	cv2jtf24,	cv3f3991,	cv3f3907,	cv3f758,	cv2btf11137,	cv2btf10955,	cv3f3823,	cv3f4100,	cv3f777,	cv2btf11167,	cv3f1537,	cv3f3983,	cv2jtf128,	cv3f3918,	cv3f3967,	cv3f877,	cv2jtf1064,	cv3f4087,	cv3f619,	scf632,	cv2btf10858,	cv2jtf83,	cv3f1538,	cv3f3908,	cv3f607,	cv3f757,	cv2btf10264,	cv2btf10822,	cv3f715,	cv2btf10758,	cv2btf10980,	cv2btf11117,	cv2btf9973,	cv2jtf1728,	cv3f3875,	cv3f4084,	cv3f4101,	cv3f615,	cv3f721,	cv2btf10736,	cv2jtf50,	cv3f3843,	cv3f3997,	cv3f625,	cv3f657,	cv2btf10854,	cv2btf11160,	cv2btf9938,	cv3f1505,	cv2btf11192,	cv2btf4475,	cv2btf9624,	cv3f1442,	cv3f639,	cv3f647,	cv3f751,	scf349,	scf356,	cv2btf10001
   from
     dmr_c.dmrc_model_t04_collect_c_score_v3_features_s_d) t2 on date_add(t1.dt, 1) = t2.dt and t1.pin = t2.pin;

--Select Count(*) From dmr_dev.bxy_tmp_btqx_loan_paid_t36_c_card_feature;
--Select * From dmr_dev.bxy_tmp_btqx_loan_paid_t36_c_card_feature;

--分组样本量验证
Select dt, ovd_stage, count(*) From dmr_dev.bxy_tmp_btqx_loan_paid_t36_c_card_feature group by dt, ovd_stage order by dt, ovd_stage;





























