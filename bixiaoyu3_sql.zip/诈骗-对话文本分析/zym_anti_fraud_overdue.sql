use dmr_dev;
DROP TABLE IF EXISTS dmr_dev.zym_anti_fraud_overdue_table_1;
create table if not exists dmr_dev.zym_anti_fraud_overdue_table_1 as
select t1.*,  t2.overdue_days, t2.cur_bal, t2.overdue_amt, t2.dt
from dmr_dev.dx_zpks_info_0 t1
left join 
(select * from dmr_c.dmrc_cs_jt_overdays_amt_s_d where product = '金条'  and overdue_days > 0) t2
on t1.pin = t2.pin and t1.order_date <= t2.dt; --在t1基础上附上overdue相关信息

-- 诈骗案件用户有多少发生金条逾期
use dmr_dev;
DROP TABLE IF EXISTS dmr_dev.zym_anti_fraud_overdue_analysis_1;
create table if not exists dmr_dev.zym_anti_fraud_overdue_analysis_1 as 
select count(*), avg(overdue_days) as avg_overdue_days, avg(cur_bals) as avg_cur_bals, avg(overdue_amts) as avg_overdue_amts,
min(overdue_days) as min_overdue_days, min(cur_bals) as min_cur_bals, min(overdue_amts) as min_overdue_amts,
max(overdue_days) as max_overdue_days, max(cur_bals) as max_cur_bals, max(overdue_amts) as max_overdue_amts,
std(overdue_days) as std_overdue_days, std(cur_bals) as std_cur_bals, std(overdue_amts) as std_overdue_amts
from
(select pin, avg(max_overdue_day) as overdue_days, avg(cur_bal) as cur_bals, avg(overdue_amt) as overdue_amts
from
(select pin, last_value(overdue_days) over(partition by pin order by overdue_days asc rows between unbounded preceding and unbounded following) as max_overdue_day,
cur_bal, overdue_amt
from dmr_dev.zym_anti_fraud_overdue_table_1 where overdue_days is not null ) t
group by pin) t1; -- 取最大逾期天数，groupby去重


-- 诈骗案件发生金条逾期的pin
use dmr_dev;
DROP TABLE IF EXISTS dmr_dev.zym_anti_fraud_overdue_pin_list;
create table if not exists dmr_dev.zym_anti_fraud_overdue_pin_list as 
select pin, order_date
from dmr_dev.zym_anti_fraud_overdue_table_1 where overdue_days is not null
group by pin, order_date;

-- 逾期催收记录
use dmr_dev;
DROP TABLE IF EXISTS dmr_dev.zym_anti_fraud_overdue_call;
create table if not exists dmr_dev.zym_anti_fraud_overdue_call as 
select *
from dmr_dev.zym_anti_fraud_overdue_pin_list t1 -- 有逾期的(pin, orderdate)

left join 
(select call_id, pin, productTypeDesc, modified_time, business_key, overdueAmount, overdueDay,  totalAmount, caseType
    from (select call_id, 
        get_json_object(t1.ext_info,'$.custKey') as pin,
        get_json_object(t1.ext_info,'$.productTypeDesc') as productTypeDesc,
        get_json_object(t1.ext_info,'$.overdueAmount') as overdueAmount,
        get_json_object(t1.ext_info,'$.overdueDay') as overdueDay,
        get_json_object(t1.ext_info,'$.totalAmount') as totalAmount,
        get_json_object(t1.ext_info,'$.caseType') as caseType,
        t1.modified_time as modified_time,  
        t1.business_key as business_key
        from odm.odm_risk_c_record_000_i_d t1
         ) temp1
    where pin in (select pin from dmr_dev.zym_anti_fraud_overdue_pin_list) and productTypeDesc = '京东金条') t2
on (t1.pin = t2.pin and t1.order_date < t2.modified_time);

-- 上表加上通话文本记录
use dmr_dev;
DROP TABLE IF EXISTS dmr_dev.zym_anti_fraud_overdue_call_2;
create table if not exists dmr_dev.zym_anti_fraud_overdue_call_2 as 
select t1.*, t2.call_text
from dmr_dev.zym_anti_fraud_overdue_call t1

left join
    --获取通话文本,通话结果是否答应还款
    (select call_id,
            collect_list(text_info) as call_text, 
            sum(case when instr(text_info,'promise') > 0 then 1 else 0 end) as is_promise -- 多余
    from (select * 
        from odm.odm_risk_c_record_sub_000_i_d 
        where call_id in (select call_id from dmr_dev.zym_anti_fraud_overdue_call) and role = 'VOICEIN_CONVERSATION'  
        ) temp
    group by call_id) t2
on (t1.call_id = t2.call_id);

use dmr_dev;
DROP TABLE IF EXISTS dmr_dev.zym_anti_fraud_overdue_call_human;
create table if not exists dmr_dev.zym_anti_fraud_overdue_call_human as 
select t1.*, t2.*
from dmr_dev.zym_anti_fraud_overdue_pin_list t1
left join dmr_c.dmrc_cs_qzm_robot_base_inspect_a_d t2
on t1.pin = t2.pin and t1.order_date < t2.urge_date;


use dmr_dev;
DROP TABLE IF EXISTS dmr_dev.zym_anti_fraud_overdue_call_normal;
create table if not exists dmr_dev.zym_anti_fraud_overdue_call_normal as 
select *
from
(select t1.*
from dmr_c.dmrc_cs_qzm_robot_base_inspect_a_d t1
where t1.pin not in (select pin from dmr_dev.zym_anti_fraud_overdue_call_human)) t
order by rand()
limit 5000;


