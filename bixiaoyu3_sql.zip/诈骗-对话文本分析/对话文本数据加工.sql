--desc odm.odm_risk_c_record_000_i_d;
--desc odm.odm_risk_c_record_sub_000_i_d;
--desc odm.odm_risk_qt_case_info_i_d;


use dmr_dev;
DROP TABLE if EXISTS dmr_dev.bxy_overdue_table_1;
CREATE TABLE if not exists dmr_dev.bxy_overdue_table_1 as
Select 
    get_json_object(ext_info,'$.custKey') as pin,
    call_id, 
    get_json_object(ext_info,'$.productTypeDesc') as product, 
    get_json_object(ext_info,'$.overdueDay') as overdue_days, 
    regexp_extract(get_json_object(ext_info,'$.overdueAmount'), '([0-9]+)\\.([0-9]+)', 0) as overdue_amt, 
    get_json_object(ext_info,'$.totalAmount') as cur_bal, 
    created_time as urge_time,
    dt
From 
    odm.odm_risk_c_record_000_i_d
Where
    get_json_object(ext_info,'$.productTypeDesc') = '京东白条' or get_json_object(ext_info,'$.productTypeDesc') = '京东金条';

--Select * From dmr_dev.bxy_overdue_table_1 limit 100;


use dmr_dev;
DROP TABLE if EXISTS dmr_dev.bxy_overdue_table_1_call_text;
CREATE TABLE if not exists dmr_dev.bxy_overdue_table_1_call_text as
Select
    t1.*, t2.duration,
    t2.text, 'robot' as call_type
From
    dmr_dev.bxy_overdue_table_1 t1 Left Join
    (Select
        call_id, 
        max(unix_timestamp(created_time))-min(unix_timestamp(created_time)) as duration,
        collect_list(concat('{"role": "', role, '", "text_info": "', text_info, '"}')) as text
     From  (Select * 
            From odm.odm_risk_c_record_sub_000_i_d 
            Where call_id in (Select call_id From dmr_dev.bxy_overdue_table_1)) temp
     Group By 
        call_id) t2 on t1.call_id = t2.call_id;

--Select * From dmr_dev.bxy_overdue_table_1_call_text limit 100;


use dmr_dev;
DROP TABLE if EXISTS dmr_dev.bxy_overdue_table_2;
CREATE TABLE if not exists dmr_dev.bxy_overdue_table_2 as
Select 
    t1.cust_key as pin,
    (Case substr(t1.product_type,-2,2) when 'BT' then '京东白条' when 'JT' then '京东金条' End) as product,
    get_json_object(t1.qt_voice_text,'$.duration')/1000 as duration,
    t2.overdue_days, t2.overdue_amt, t2.cur_bal, t1.urge_time, to_date(t1.urge_time) as dt,
    split(regexp_replace(regexp_extract(get_json_object(qt_voice_text,'$.sentenceList'),'^\\[(.+)\\]$',1),'\\}\\,\\{', '\\}\\|\\|\\{'), '\\|\\|') as text,
    'human' as call_type
From 
    odm.odm_risk_qt_case_info_i_d t1 Left Join
    (Select 
        pin, overdue_days, overdue_amt, cur_bal, dt, 'JT' as product
     From 
        dmr_c.dmrc_cs_jt_overdays_amt_s_d 
     Where 
        overdue_days > 0
     Union
     Select 
        pin, overdue_days, overdue_amt, cur_bal, dt, 'BT' as product
     From 
        dmr_c.dmrc_cs_bt_overdays_amt_s_d 
     Where 
        overdue_days > 0) t2 on t1.cust_key = t2.pin and 
        substr(t1.product_type,-2,2) = t2.product and 
        t1.dt = t2.dt; --在t1基础上附上overdue相关信息

--Select * From dmr_dev.bxy_overdue_table_2 limit 100;

--人工表去重
use dmr_dev;
DROP TABLE if EXISTS dmr_dev.bxy_overdue_table_2_dropdup;
CREATE TABLE if not exists dmr_dev.bxy_overdue_table_2_dropdup as
Select 
    pin, product, duration, min(overdue_days) as overdue_days, overdue_amt, cur_bal, min(urge_time) as urge_time, 
    min(dt) as dt, text, call_type
From 
    dmr_dev.bxy_overdue_table_2
Group By 
    pin, product, duration, overdue_amt, cur_bal, text, call_type;


--人工表拼接连续对话
use dmr_dev;
DROP TABLE if EXISTS dmr_dev.bxy_overdue_table_2_merge;
CREATE TABLE if not exists dmr_dev.bxy_overdue_table_2_merge as
Select 
    t1.pin, t1.product, t1.call_type, t1.overdue_days, t1.overdue_amt, t1.cur_bal, 
    t2.start_urge_time as urge_time, t2.duration, t2.merge_text as text, t1.dt
From
    dmr_dev.bxy_overdue_table_2_dropdup t1 Inner join
    (Select 
        pin, product, call_type, dt, start_urge_time, sum(duration) as duration, min(overdue_days) as overdue_days,
        collect_list(concat_ws(',', text)) as merge_text
    From
        (Select
            pin, product, call_type, dt, text, duration, overdue_days,
            Case When (unix_timestamp(urge_time) - unix_timestamp(last_urge_time)) < 600 Then last_urge_time 
                       Else urge_time End as start_urge_time
        From
            (Select 
                pin, product, call_type, dt, text, urge_time, duration, overdue_days,
                lag(urge_time, 1) over(partition by pin, product, call_type, dt order by urge_time) as last_urge_time
            From 
                dmr_dev.bxy_overdue_table_2_dropdup))
    Group By 
        pin, product, call_type, dt, start_urge_time) t2 on t1.pin = t2.pin and 
        t1.product = t2.product and t1.call_type = t2.call_type and t1.dt = t2.dt and t1.overdue_days = t2.overdue_days
Group By 
        t1.pin, t1.product, t1.call_type, t1.overdue_days, t1.overdue_amt, t1.cur_bal, 
        t2.start_urge_time, t2.duration, t2.merge_text, t1.dt;


use dmr_dev;
DROP TABLE if EXISTS dmr_dev.bxy_overdue_table_with_call_text;
CREATE TABLE if not exists dmr_dev.bxy_overdue_table_with_call_text as
Select 
    pin, product, call_type, overdue_days, overdue_amt, cur_bal, urge_time, duration,
    floor(size(text)/2) as call_round, text, dt
From 
    dmr_dev.bxy_overdue_table_1_call_text
Where 
    pin is not null and product is not null and call_type is not null
Union
Select
    pin, product, call_type, overdue_days, overdue_amt, cur_bal, urge_time, round(duration),
    floor(size(text)/2) as call_round, text, dt
From
    dmr_dev.bxy_overdue_table_2_merge
Where
    size(text) >= 0 and pin is not null;
    
--Select * From dmr_dev.bxy_overdue_table_with_call_text;
--Select Count(*) From dmr_dev.bxy_overdue_table_with_call_text;




















