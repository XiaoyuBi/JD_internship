Select 
    dt,
    Sum(Case When concat_ws(' ',text) like '%诈骗%' Then 1 Else 0 End) as `诈骗1`,
    Sum(Case When concat_ws(' ',text) like '%立案%' Then 1 Else 0 End) as `立案2`,
    Sum(Case When concat_ws(' ',text) like '%报警%' Then 1 Else 0 End) as `报警3`,
    Sum(Case When concat_ws(' ',text) like '%警方%' Then 1 Else 0 End) as `警方4`,
    Sum(Case When concat_ws(' ',text) like '%报案%' Then 1 Else 0 End) as `报案5`,
    Sum(Case When concat_ws(' ',text) like '%警察%' Then 1 Else 0 End) as `警察6`,
    Sum(Case When concat_ws(' ',text) like '%骗子%' Then 1 Else 0 End) as `骗子7`,
    Sum(Case When concat_ws(' ',text) like '%派出所%' Then 1 Else 0 End) as `派出所8`,
    Sum(Case When concat_ws(' ',text) like '%被盗%' Then 1 Else 0 End) as `被盗9`,
    Sum(Case When concat_ws(' ',text) like '%骗走%' Then 1 Else 0 End) as `骗走10`,
    Sum(Case When concat_ws(' ',text) like '%诈骗%' Then 1 Else 0 End)/count(*) as `诈骗比例1`,
    Sum(Case When concat_ws(' ',text) like '%立案%' Then 1 Else 0 End)/count(*) as `立案比例2`,
    Sum(Case When concat_ws(' ',text) like '%报警%' Then 1 Else 0 End)/count(*) as `报警比例3`,
    Sum(Case When concat_ws(' ',text) like '%警方%' Then 1 Else 0 End)/count(*) as `警方比例4`,
    Sum(Case When concat_ws(' ',text) like '%报案%' Then 1 Else 0 End)/count(*) as `报案比例5`,
    Sum(Case When concat_ws(' ',text) like '%警察%' Then 1 Else 0 End)/count(*) as `警察比例6`,
    Sum(Case When concat_ws(' ',text) like '%骗子%' Then 1 Else 0 End)/count(*) as `骗子比例7`,
    Sum(Case When concat_ws(' ',text) like '%派出所%' Then 1 Else 0 End)/count(*) as `派出所比例8`,
    Sum(Case When concat_ws(' ',text) like '%被盗%' Then 1 Else 0 End)/count(*) as `被盗比例9`,
    Sum(Case When concat_ws(' ',text) like '%骗走%' Then 1 Else 0 End)/count(*) as `骗走比例10`
From
    dmr_dev.bxy_overdue_table_with_call_text
Where
    dt >= '2020-05-01'
Group By
    dt
Order By
    dt;
    

Select 
    dt,
    Sum(Case When concat_ws(' ',text) like '%诈骗%' Then 1 Else 0 End) as `诈骗1`,
    Sum(Case When concat_ws(' ',text) like '%立案%' Then 1 Else 0 End) as `立案2`,
    Sum(Case When concat_ws(' ',text) like '%报警%' Then 1 Else 0 End) as `报警3`,
    Sum(Case When concat_ws(' ',text) like '%警方%' Then 1 Else 0 End) as `警方4`,
    Sum(Case When concat_ws(' ',text) like '%报案%' Then 1 Else 0 End) as `报案5`,
    Sum(Case When concat_ws(' ',text) like '%警察%' Then 1 Else 0 End) as `警察6`,
    Sum(Case When concat_ws(' ',text) like '%骗子%' Then 1 Else 0 End) as `骗子7`,
    Sum(Case When concat_ws(' ',text) like '%派出所%' Then 1 Else 0 End) as `派出所8`,
    Sum(Case When concat_ws(' ',text) like '%被盗%' Then 1 Else 0 End) as `被盗9`,
    Sum(Case When concat_ws(' ',text) like '%骗走%' Then 1 Else 0 End) as `骗走10`,
    Sum(Case When concat_ws(' ',text) like '%诈骗%' Then 1 Else 0 End)/count(*) as `诈骗比例1`,
    Sum(Case When concat_ws(' ',text) like '%立案%' Then 1 Else 0 End)/count(*) as `立案比例2`,
    Sum(Case When concat_ws(' ',text) like '%报警%' Then 1 Else 0 End)/count(*) as `报警比例3`,
    Sum(Case When concat_ws(' ',text) like '%警方%' Then 1 Else 0 End)/count(*) as `警方比例4`,
    Sum(Case When concat_ws(' ',text) like '%报案%' Then 1 Else 0 End)/count(*) as `报案比例5`,
    Sum(Case When concat_ws(' ',text) like '%警察%' Then 1 Else 0 End)/count(*) as `警察比例6`,
    Sum(Case When concat_ws(' ',text) like '%骗子%' Then 1 Else 0 End)/count(*) as `骗子比例7`,
    Sum(Case When concat_ws(' ',text) like '%派出所%' Then 1 Else 0 End)/count(*) as `派出所比例8`,
    Sum(Case When concat_ws(' ',text) like '%被盗%' Then 1 Else 0 End)/count(*) as `被盗比例9`,
    Sum(Case When concat_ws(' ',text) like '%骗走%' Then 1 Else 0 End)/count(*) as `骗走比例10`
From
    dmr_dev.bxy_overdue_table_with_call_text
Where 
    call_type = 'robot' and
    dt >= '2020-05-01'
Group By
    dt
Order By
    dt;  


Select 
    dt,
    Sum(Case When concat_ws(' ',text) like '%诈骗%' Then 1 Else 0 End) as `诈骗1`,
    Sum(Case When concat_ws(' ',text) like '%立案%' Then 1 Else 0 End) as `立案2`,
    Sum(Case When concat_ws(' ',text) like '%报警%' Then 1 Else 0 End) as `报警3`,
    Sum(Case When concat_ws(' ',text) like '%警方%' Then 1 Else 0 End) as `警方4`,
    Sum(Case When concat_ws(' ',text) like '%报案%' Then 1 Else 0 End) as `报案5`,
    Sum(Case When concat_ws(' ',text) like '%警察%' Then 1 Else 0 End) as `警察6`,
    Sum(Case When concat_ws(' ',text) like '%骗子%' Then 1 Else 0 End) as `骗子7`,
    Sum(Case When concat_ws(' ',text) like '%派出所%' Then 1 Else 0 End) as `派出所8`,
    Sum(Case When concat_ws(' ',text) like '%被盗%' Then 1 Else 0 End) as `被盗9`,
    Sum(Case When concat_ws(' ',text) like '%骗走%' Then 1 Else 0 End) as `骗走10`,
    Sum(Case When concat_ws(' ',text) like '%诈骗%' Then 1 Else 0 End)/count(*) as `诈骗比例1`,
    Sum(Case When concat_ws(' ',text) like '%立案%' Then 1 Else 0 End)/count(*) as `立案比例2`,
    Sum(Case When concat_ws(' ',text) like '%报警%' Then 1 Else 0 End)/count(*) as `报警比例3`,
    Sum(Case When concat_ws(' ',text) like '%警方%' Then 1 Else 0 End)/count(*) as `警方比例4`,
    Sum(Case When concat_ws(' ',text) like '%报案%' Then 1 Else 0 End)/count(*) as `报案比例5`,
    Sum(Case When concat_ws(' ',text) like '%警察%' Then 1 Else 0 End)/count(*) as `警察比例6`,
    Sum(Case When concat_ws(' ',text) like '%骗子%' Then 1 Else 0 End)/count(*) as `骗子比例7`,
    Sum(Case When concat_ws(' ',text) like '%派出所%' Then 1 Else 0 End)/count(*) as `派出所比例8`,
    Sum(Case When concat_ws(' ',text) like '%被盗%' Then 1 Else 0 End)/count(*) as `被盗比例9`,
    Sum(Case When concat_ws(' ',text) like '%骗走%' Then 1 Else 0 End)/count(*) as `骗走比例10`
From
    dmr_dev.bxy_overdue_table_with_call_text
Where 
    call_type = 'human' and
    dt >= '2020-05-01'
Group By
    dt
Order By
    dt;  
