--用户级_对话文本分析

use dmr_dev;
DROP TABLE IF EXISTS dmr_dev.bxy_overdue_table_with_call_text_jieba_pinbased;
create table if not exists dmr_dev.bxy_overdue_table_with_call_text_jieba_pinbased as
Select
    pin, product, call_type,
    min(dt) as first_date, max(dt) as last_date,
    count(*) as `urge#`,
    max(overdue_days) as max_overdue_days,
    max(overdue_amt) as max_overdue_amt,
    max(cur_bal) as max_cur_bal,
    sum(Case When array_contains(user_jieba_text, '诈骗') then 1 Else 0 End) as zhapian,
    sum(Case When array_contains(user_jieba_text, '立案') then 1 Else 0 End) as lian,
    sum(Case When array_contains(user_jieba_text, '报警') then 1 Else 0 End) as baojing,
    sum(Case When array_contains(user_jieba_text, '警方') then 1 Else 0 End) as jingfang,
    sum(Case When array_contains(user_jieba_text, '报案') then 1 Else 0 End) as baoan,
    sum(Case When array_contains(user_jieba_text, '警察') then 1 Else 0 End) as jingcha,
    sum(Case When array_contains(user_jieba_text, '骗子') then 1 Else 0 End) as pianzi,
    sum(Case When array_contains(user_jieba_text, '派出所') then 1 Else 0 End) as paichusuo,
    sum(Case When array_contains(user_jieba_text, '被盗') then 1 Else 0 End) as beidao,
    sum(Case When array_contains(user_jieba_text, '骗走') then 1 Else 0 End) as pianzou
From
    dmr_dev.bxy_overdue_table_with_call_text_jieba
Group By
    pin, product, call_type
Order By
    zhapian DESC;

Select * From dmr_dev.bxy_overdue_table_with_call_text_jieba_pinbased limit 100;
Select * From dmr_dev.bxy_overdue_table_with_call_text_jieba_pinbased order by rand() limit 100;

Select 
    sum(Case When zhapian > 0 Then 1 Else 0 End)/count(*) as `zhapian%`,
    sum(Case When lian > 0 Then 1 Else 0 End)/count(*) as `lian%`,
    sum(Case When baojing > 0 Then 1 Else 0 End)/count(*) as `baojing%`,
    sum(Case When jingfang > 0 Then 1 Else 0 End)/count(*) as `jingfang%`,
    sum(Case When baoan > 0 Then 1 Else 0 End)/count(*) as `baoan%`,
    sum(Case When jingcha > 0 Then 1 Else 0 End)/count(*) as `jingcha%`,
    sum(Case When pianzi > 0 Then 1 Else 0 End)/count(*) as `pianzi%`,
    sum(Case When paichusuo > 0 Then 1 Else 0 End)/count(*) as `paichusuo%`,
    sum(Case When beidao > 0 Then 1 Else 0 End)/count(*) as `beidao%`,
    sum(Case When pianzou > 0 Then 1 Else 0 End)/count(*) as `pianzou%`
From 
    dmr_dev.bxy_overdue_table_with_call_text_jieba_pinbased;


--通话转化分析
desc dmr_c.dmrc_cs_qzm_col_record_union_a_d;
Select * From dmr_c.dmrc_cs_qzm_col_record_union_a_d limit 100;

Select
    product, t1.call_type, col_date,
    count(*) as record_count,
    sum(get_through) as through_count,
    sum(Case When get_through = 1 and t2.pin is not null then 1 Else 0 End) as ovd_table_count
From
    (Select 
        pin, product, col_date,
        (Case When action_code in ('电话', 'OC') Then 'human'
              When action_code = 'IVR' Then 'robot'
              Else 'other' End) as call_type,
        (Case When call_state in ('接通', '成功', 1) Then 1 Else 0 End) as get_through,
        (Case When relation like '%本人' or relation in (1, 26, 38, 64) Then 1 Else 0 End) as self
    From
        dmr_c.dmrc_cs_qzm_col_record_union_a_d
    Where
        product = '金条' or product = '白条') t1 left join 
    (Select
        pin, call_type, urge_time
    From 
        dmr_dev.bxy_overdue_table_with_call_text) t2 on t1.pin = t2.pin and t1.col_date = substring(t2.urge_time, 1, 10)
Group By
    product, t1.call_type, col_date
Having
    t1.call_type in ('human', 'robot')
Order By
    col_date DESC;


--通话转化分析new
Select 
    t1.col_date, t1.product, t1.call_type,
    sum(t1.record_count), 
    sum(t1.through_count), 
    sum(t2.ovd_table_count)
From
    (Select
        col_date, pin, product, call_type,
        count(*) as record_count,
        sum(get_through) as through_count
    From
        (Select 
            pin, product, col_date,
            (Case When action_code in ('电话', 'OC') Then 'human'
                  When action_code = 'IVR' Then 'robot'
                  Else 'other' End) as call_type,
            (Case When call_state in ('接通', '成功', 1) Then 1 Else 0 End) as get_through,
            (Case When relation like '%本人' or relation in (1, 26, 38, 64) Then 1 Else 0 End) as self
        From
            dmr_c.dmrc_cs_qzm_col_record_union_a_d
        Where
            product = '金条' or product = '白条')
    Where 
        call_type in ('human', 'robot')
    Group By
        col_date, pin, product, call_type
    Order By
        col_date DESC , pin, product, call_type) t1 left join
    (Select 
        substring(urge_time, 1, 10) as col_date, pin, substring(product, 3, 2) as product, call_type,
        count(*) as ovd_table_count
    From 
        dmr_dev.bxy_overdue_table_with_call_text
    Group By
        substring(urge_time, 1, 10), pin, substring(product, 3, 2), call_type
    Order By
        substring(urge_time, 1, 10) DESC , pin, substring(product, 3, 2), call_type) t2 
    on t1.col_date = t2.col_date and 
       t1.pin = t2.pin and t1.product = t2.product and t1.call_type = t2.call_type
Group By
    t1.col_date, t1.product, t1.call_type
Order By
    t1.col_date DESC;



Select * From dmr_c.dmrc_cs_qzm_col_record_union_a_d Where col_date = '2020-09-01';
Select * From odm.odm_risk_qt_case_info_i_d Where cust_key = 'a873771';
Select * From odm.odm_risk_qt_case_info_i_d Where cust_key = 'jd_QkHrhwgXsdlj';





