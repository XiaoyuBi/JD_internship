--白 条 
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_bt_mv_amount_dd_a_d_month_end2;
create table dmr_dev.juxin_tmp_dmrc_cs_bt_mv_amount_dd_a_d_month_end2 as
select
  dt,
  (case
    when overdue_days<=60 then 'M2'
    when overdue_days<=90 then 'M3'
    when overdue_days<=120 then 'M4'
    when overdue_days<=150 then 'M5'
    when overdue_days<=180 then 'M6'
    when overdue_days<=210 then 'M7'
    when overdue_days<=300 then '211-300'
    when overdue_days<=390 then '301-390'
    else '391+' end) as ovd_stage,
  overdue_days,
  user_pin as pin,
  jd_order_id as orderid,
  cur_bal,
  cur_bal + shld_inst - real_inst + shld_svc_fee - real_svc_fee as cur_bal_total
from
  dmr_bc.dmrbc_cf_bt_loan_s_d
where
  dt in ('2019-01-01','2019-02-01','2019-03-01','2019-04-01','2019-05-01','2019-06-01','2019-07-01','2019-08-01','2019-09-01','2019-10-01','2019-11-01','2019-12-01')
  and overdue_days > 30;

--先 按 订 单 汇 总 
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_bt_mv_amount_dd_a_d_month_end_dd;
create table dmr_dev.juxin_tmp_dmrc_cs_bt_mv_amount_dd_a_d_month_end_dd as
select
  dt,
  pin,
  orderid,
  ovd_stage,
  max(overdue_days) as overdue_days,
  sum(cur_bal) as cur_bal,
  sum(cur_bal_total) as cur_bal_total
from
  dmr_dev.juxin_tmp_dmrc_cs_bt_mv_amount_dd_a_d_month_end2
group by
  dt,
  pin,
  orderid,
  ovd_stage;

--抽 样 108 万 笔 订 单 
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_bt_sample_id;
create table dmr_dev.juxin_tmp_dmrc_cs_bt_sample_id as
select
  dt,
  pin,
  orderid
from(
    select
      dt,
      pin,
      orderid,
      row_number() over(
        partition by dt, ovd_stage
        order by rand()
      ) row_id
    from
      dmr_dev.juxin_tmp_dmrc_cs_bt_mv_amount_dd_a_d_month_end_dd
  ) as a
where
  row_id <= 10000
group by
  dt,
  pin,
  orderid;

--匹配抽样样本
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_bt_mv_amount_dd_a_d_month_end_dd_sampled;
create table dmr_dev.juxin_tmp_dmrc_cs_bt_mv_amount_dd_a_d_month_end_dd_sampled as
select
  t2.*
from
  dmr_dev.juxin_tmp_dmrc_cs_bt_sample_id t1 left join dmr_dev.juxin_tmp_dmrc_cs_bt_mv_amount_dd_a_d_month_end_dd t2 on 
  t1.pin = t2.pin and t1.orderid = t2.orderid and t1.dt = t2.dt;

--匹 配 还 款 
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_bt_mv_amount_dd_a_d_month_end_payamount_2017;
create table dmr_dev.juxin_tmp_dmrc_cs_bt_mv_amount_dd_a_d_month_end_payamount_2017 as
select
  a.dt,
  a.pin,
  a.orderid,
  a.ovd_stage,
  a.overdue_days,
  a.cur_bal,
  a.cur_bal_total,
  case when b.paydate > a.dt then b.paymonth end as paymonth,
  sum(case when b.paydate > a.dt then amount end) as amount
from
  (
    select
      *
    from
      dmr_dev.juxin_tmp_dmrc_cs_bt_mv_amount_dd_a_d_month_end_dd_sampled
    where
      overdue_days > 0
  ) a
  left join (
    select
      *,
      substring(paydate, 1, 7) as paymonth
    from
      dmr_c.dmrc_cs_repayment_dd_a_d
    where
      product = '白条'
      and paydate <= '2020-12-30'
  ) b on a.orderid = b.orderid
group by
  a.dt,
  a.pin,
  a.orderid,
  a.ovd_stage,
  a.overdue_days,
  a.cur_bal,
  a.cur_bal_total,
  case when b.paydate > a.dt then b.paymonth end;

--计 算 月 份 差 
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_bt_mv_amount_dd_a_d_month_end_payamount_2017_diff;
create table dmr_dev.juxin_tmp_dmrc_cs_bt_mv_amount_dd_a_d_month_end_payamount_2017_diff as
select
  *,
  substring(paymonth, 1, 4) * 12 - substring(dt, 1, 4) * 12 + substring(paymonth, 6, 2) - substring(dt, 6, 2) as diff_month
from
  dmr_dev.juxin_tmp_dmrc_cs_bt_mv_amount_dd_a_d_month_end_payamount_2017;

--统 计 一 年 内 回 款 
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_bt2;
create table dmr_dev.juxin_tmp_dmrc_cs_bt2 as
select
  dt,
  pin,
  orderid,
  sum(amount) as amount
from
  dmr_dev.juxin_tmp_dmrc_cs_bt_mv_amount_dd_a_d_month_end_payamount_2017_diff
where
  diff_month <= 12.0
group by
  dt,
  pin,
  orderid;

--拼 接 年 回 款 和 C 卡 分 
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_bt3;
create table dmr_dev.juxin_tmp_dmrc_cs_bt3 as
select
  a.*,
  b.amount as amount_year,
  c.score
from
  juxin_tmp_dmrc_cs_bt_mv_amount_dd_a_d_month_end_payamount_2017_diff a
  left join dmr_dev.juxin_tmp_dmrc_cs_bt2 b on a.pin = b.pin
  and a.dt = b.dt
  and a.orderid = b.orderid
  left join (
    select
      pin,
      dt,
      score
    from
      dmr_c.dmrc_model_t04_collect_bt_c_score_s_d
  ) c on a.pin = c.pin
  and a.dt = date_add(c.dt, 1);

--整 理 数 据 字 段 
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_bt4;
create table dmr_dev.juxin_tmp_dmrc_cs_bt4 as
select
  dt,
  pin,
  orderid,
  max(ovd_stage) as ovd_stage,
  max(overdue_days) as overdue_days,
  max(cur_bal) as overdue_amt,
  max(cur_bal_total) as cur_bal_total,
  max(paymonth) as repay_month,
  max(diff_month) as repay_month_diff,
  max(amount_year) as total_repay_amount,
  max(amount) as repay_amount,
  max(score) as c_score,
  max(case when amount_year >= cur_bal then 1 else 0 end) as if_repay
from
  dmr_dev.juxin_tmp_dmrc_cs_bt3
group by 
  dt,
  pin,
  orderid;

--C卡V3特征表

--拼接C卡特征（重要度前102）
set mapreduce.map.memory.mb=8192; 
set mapreduce.map.java.opts=-Xmx7200m;
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_bt4_c_card_feature;
create table dmr_dev.juxin_tmp_dmrc_cs_bt4_c_card_feature as
select
  t1.orderid, t1.ovd_stage, t1.overdue_days, t1.overdue_amt, t1.cur_bal_total, t1.repay_month, t1.repay_month_diff, t1.total_repay_amount, 
  t1.repay_amount, t1.c_score, t1.if_repay,
  t2.*
from
  dmr_dev.juxin_tmp_dmrc_cs_bt4 t1 left join 
  (select
   pin, dt, cv2btf11166,	cv3f7,	cv2jtf1407,	cv3f4086,	cv2btf11161,	cv2btf7988,	cv2jtf987,	cv3f3889,	cv2btf11150,	cv3f3863,	cv3f3881,	cv3f3895,	cv2btf10802,	device_brand_cnt,	cv3f3905,	cv2jtf218,	cv3f3965,	cv3f9,	cv2btf11158,	cv2btf11163,	cv3f3803,	cv2jtf379,	cv3f6,	cv2btf11177,	cv2jtf24,	cv3f3991,	cv3f3907,	cv3f758,	cv2btf11137,	cv2btf10955,	cv3f3823,	cv3f4100,	cv3f777,	cv2btf11167,	cv3f1537,	cv3f3983,	cv2jtf128,	cv3f3918,	cv3f3967,	cv3f877,	cv2jtf1064,	cv3f4087,	cv3f619,	scf632,	cv2btf10858,	cv2jtf83,	cv3f1538,	cv3f3908,	cv3f607,	cv3f757,	cv2btf10264,	cv2btf10822,	cv3f715,	cv2btf10758,	cv2btf10980,	cv2btf11117,	cv2btf9973,	cv2jtf1728,	cv3f3875,	cv3f4084,	cv3f4101,	cv3f615,	cv3f721,	cv2btf10736,	cv2jtf50,	cv3f3843,	cv3f3997,	cv3f625,	cv3f657,	cv2btf10854,	cv2btf11160,	cv2btf9938,	cv3f1505,	cv2btf11192,	cv2btf4475,	cv2btf9624,	cv3f1442,	cv3f639,	cv3f647,	cv3f751,	scf349,	scf356,	cv2btf10001
   from
     dmr_c.dmrc_model_t04_collect_c_score_v3_features_s_d) t2 on t1.dt = t2.dt and t1.pin = t2.pin;


--* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

--金 条 
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_jt_mv_amount_dd_a_d_month_end2;
create table dmr_dev.juxin_tmp_dmrc_cs_jt_mv_amount_dd_a_d_month_end2 as
select
  dt,
  (case
    when overduedays<=60 then 'M2'
    when overduedays<=90 then 'M3'
    when overduedays<=120 then 'M4'
    when overduedays<=150 then 'M5'
    when overduedays<=180 then 'M6'
    when overduedays<=210 then 'M7'
    when overduedays<=300 then '211-300'
    when overduedays<=390 then '301-390'
    else '391+' end) as ovd_stage,
  overduedays as overdue_days,
  user_pin as pin,
  orderid,
  cur_bal,
  cur_bal+shld_dayamount-real_dayamount+shld_overamount-real_overamount as cur_bal_total
from
  dmr_bc.dmrbc_cf_jt_loan_s_d
where
  dt in ('2019-01-01','2019-02-01','2019-03-01','2019-04-01','2019-05-01','2019-06-01','2019-07-01','2019-08-01','2019-09-01','2019-10-01','2019-11-01','2019-12-01')
  and overduedays > 30;

--先 按 订 单 汇 总 
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_jt_mv_amount_dd_a_d_month_end_dd;
create table dmr_dev.juxin_tmp_dmrc_cs_jt_mv_amount_dd_a_d_month_end_dd as
select
  dt,
  pin,
  orderid,
  ovd_stage,
  max(overdue_days) as overdue_days,
  sum(cur_bal) as cur_bal,
  sum(cur_bal_total) as cur_bal_total
from
  dmr_dev.juxin_tmp_dmrc_cs_jt_mv_amount_dd_a_d_month_end2
group by
  dt,
  pin,
  orderid,
  ovd_stage;

--抽 样 108 万 笔 订 单 
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_jt_sample_id;
create table dmr_dev.juxin_tmp_dmrc_cs_jt_sample_id as
select
  dt,
  pin,
  orderid
from(
    select
      dt,
      pin,
      orderid,
      row_number() over(
        partition by dt, ovd_stage
        order by rand()
      ) row_id
    from
      dmr_dev.juxin_tmp_dmrc_cs_jt_mv_amount_dd_a_d_month_end_dd
  ) as a
where
  row_id <= 10000
group by
  dt,
  pin,
  orderid;

--匹配抽样样本
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_jt_mv_amount_dd_a_d_month_end_dd_sampled;
create table dmr_dev.juxin_tmp_dmrc_cs_jt_mv_amount_dd_a_d_month_end_dd_sampled as
select
  t2.*
from
  dmr_dev.juxin_tmp_dmrc_cs_jt_sample_id t1 left join dmr_dev.juxin_tmp_dmrc_cs_jt_mv_amount_dd_a_d_month_end_dd t2 on 
  t1.pin = t2.pin and t1.orderid = t2.orderid and t1.dt = t2.dt;

--匹 配 还 款 
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_jt_mv_amount_dd_a_d_month_end_payamount_2017;
create table dmr_dev.juxin_tmp_dmrc_cs_jt_mv_amount_dd_a_d_month_end_payamount_2017 as
select
  a.dt,
  a.pin,
  a.orderid,
  a.ovd_stage,
  a.overdue_days,
  a.cur_bal,
  a.cur_bal_total,
  case when b.paydate > a.dt then b.paymonth end as paymonth,
  sum(case when b.paydate > a.dt then amount end) as amount
from
  (
    select
      *
    from
      dmr_dev.juxin_tmp_dmrc_cs_jt_mv_amount_dd_a_d_month_end_dd_sampled
    where
      overdue_days > 0
  ) a
  left join (
    select
      *,
      substring(paydate, 1, 7) as paymonth
    from
      dmr_c.dmrc_cs_repayment_dd_a_d
    where
      product = '金条'
      and paydate <= '2020-12-30'
  ) b on a.orderid = b.orderid
group by
  a.dt,
  a.pin,
  a.orderid,
  a.ovd_stage,
  a.overdue_days,
  a.cur_bal,
  a.cur_bal_total,
  case when b.paydate > a.dt then b.paymonth end;

--计 算 月 份 差 
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_jt_mv_amount_dd_a_d_month_end_payamount_2017_diff;
create table dmr_dev.juxin_tmp_dmrc_cs_jt_mv_amount_dd_a_d_month_end_payamount_2017_diff as
select
  *,
  substring(paymonth, 1, 4) * 12 - substring(dt, 1, 4) * 12 + substring(paymonth, 6, 2) - substring(dt, 6, 2) as diff_month
from
  dmr_dev.juxin_tmp_dmrc_cs_jt_mv_amount_dd_a_d_month_end_payamount_2017;

--统 计 一 年 内 回 款 
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_jt2;
create table dmr_dev.juxin_tmp_dmrc_cs_jt2 as
select
  dt,
  pin,
  orderid,
  sum(amount) as amount
from
  dmr_dev.juxin_tmp_dmrc_cs_jt_mv_amount_dd_a_d_month_end_payamount_2017_diff
where
  diff_month <= 12.0
group by
  dt,
  pin,
  orderid;

--拼 接 年 回 款 和 C 卡 分 
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_jt3;
create table dmr_dev.juxin_tmp_dmrc_cs_jt3 as
select
  a.*,
  b.amount as amount_year,
  c.score
from
  juxin_tmp_dmrc_cs_jt_mv_amount_dd_a_d_month_end_payamount_2017_diff a
  left join dmr_dev.juxin_tmp_dmrc_cs_jt2 b on a.pin = b.pin
  and a.dt = b.dt
  and a.orderid = b.orderid
  left join (
    select
      pin,
      dt,
      score
    from
      dmr_c.dmrc_model_t04_collect_bt_c_score_s_d
  ) c on a.pin = c.pin
  and a.dt = date_add(c.dt, 1);

--整 理 数 据 字 段 
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_jt4;
create table dmr_dev.juxin_tmp_dmrc_cs_jt4 as
select
  dt,
  pin,
  orderid,
  max(ovd_stage) as ovd_stage,
  max(overdue_days) as overdue_days,
  max(cur_bal) as overdue_amt,
  max(cur_bal_total) as cur_bal_total,
  max(paymonth) as repay_month,
  max(diff_month) as repay_month_diff,
  max(amount_year) as total_repay_amount,
  max(amount) as repay_amount,
  max(score) as c_score,
  max(case when amount_year >= cur_bal then 1 else 0 end) as if_repay
from
  dmr_dev.juxin_tmp_dmrc_cs_jt3
group by 
  dt,
  pin,
  orderid;

--拼接C卡特征（重要度前102）
set mapreduce.map.memory.mb=8192; 
set mapreduce.map.java.opts=-Xmx7200m;
use dmr_dev;
drop table if exists dmr_dev.juxin_tmp_dmrc_cs_jt4_c_card_feature;
create table dmr_dev.juxin_tmp_dmrc_cs_jt4_c_card_feature as
select
  t1.orderid, t1.ovd_stage, t1.overdue_days, t1.overdue_amt, t1.cur_bal_total, t1.repay_month, t1.repay_month_diff, t1.total_repay_amount, 
  t1.repay_amount, t1.c_score, t1.if_repay,
  t2.*
from
  dmr_dev.juxin_tmp_dmrc_cs_jt4 t1 left join 
  (select
   pin, dt, cv2btf11166,	cv3f7,	cv2jtf1407,	cv3f4086,	cv2btf11161,	cv2btf7988,	cv2jtf987,	cv3f3889,	cv2btf11150,	cv3f3863,	cv3f3881,	cv3f3895,	cv2btf10802,	device_brand_cnt,	cv3f3905,	cv2jtf218,	cv3f3965,	cv3f9,	cv2btf11158,	cv2btf11163,	cv3f3803,	cv2jtf379,	cv3f6,	cv2btf11177,	cv2jtf24,	cv3f3991,	cv3f3907,	cv3f758,	cv2btf11137,	cv2btf10955,	cv3f3823,	cv3f4100,	cv3f777,	cv2btf11167,	cv3f1537,	cv3f3983,	cv2jtf128,	cv3f3918,	cv3f3967,	cv3f877,	cv2jtf1064,	cv3f4087,	cv3f619,	scf632,	cv2btf10858,	cv2jtf83,	cv3f1538,	cv3f3908,	cv3f607,	cv3f757,	cv2btf10264,	cv2btf10822,	cv3f715,	cv2btf10758,	cv2btf10980,	cv2btf11117,	cv2btf9973,	cv2jtf1728,	cv3f3875,	cv3f4084,	cv3f4101,	cv3f615,	cv3f721,	cv2btf10736,	cv2jtf50,	cv3f3843,	cv3f3997,	cv3f625,	cv3f657,	cv2btf10854,	cv2btf11160,	cv2btf9938,	cv3f1505,	cv2btf11192,	cv2btf4475,	cv2btf9624,	cv3f1442,	cv3f639,	cv3f647,	cv3f751,	scf349,	scf356,	cv2btf10001
   from
     dmr_c.dmrc_model_t04_collect_c_score_v3_features_s_d) t2 on t1.dt = t2.dt and t1.pin = t2.pin;
     
     
