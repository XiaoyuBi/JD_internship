use dmr_dev;
drop table if exists dmr_dev.bxy_tmp1;
create table dmr_dev.bxy_tmp1 as
select 
    user_id, case_id, dt, url, timestamp_s
from 
    dmr_dev.bxy_action_sequence_pattern_mining_1;

--获取上个非空case_id
use dmr_dev;
drop table if exists dmr_dev.bxy_tmp2;
create table dmr_dev.bxy_tmp2 as
select
    user_id,
    last_value(case_id, True) over(partition by user_id, dt order by timestamp_s) as case_id,
    dt, url, timestamp_s
from 
    dmr_dev.bxy_tmp1;

--获取上个case_id
use dmr_dev;
drop table if exists dmr_dev.bxy_tmp3;
create table dmr_dev.bxy_tmp3 as
select
    user_id, case_id,
    lag(case_id, 1) over(partition by user_id, dt order by timestamp_s) as lag_case_id,
    dt, url, timestamp_s
from 
    dmr_dev.bxy_tmp2;

--比较本case与上个case是否相同，不同标记为1
use dmr_dev;
drop table if exists dmr_dev.bxy_tmp4;
create table dmr_dev.bxy_tmp4 as
select
    user_id, case_id, lag_case_id,
    Case When case_id is not null and lag_case_id is not null and case_id <> lag_case_id then 1 Else 0 End as session_flag,
    dt, url, timestamp_s
from 
    dmr_dev.bxy_tmp3;

--做累加和形成session_id
use dmr_dev;
drop table if exists dmr_dev.bxy_tmp5;
create table dmr_dev.bxy_tmp5 as
select
    user_id, case_id,
    sum(session_flag) OVER (partition by user_id, dt order by timestamp_s ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as session_id,
    dt, url, timestamp_s
from 
    dmr_dev.bxy_tmp4;

select * from dmr_dev.bxy_tmp1;
select * from dmr_dev.bxy_tmp2;
select * from dmr_dev.bxy_tmp3;
select * from dmr_dev.bxy_tmp4;
select * from dmr_dev.bxy_tmp5;

--session分析
use dmr_dev;
drop table if exists dmr_dev.bxy_tmp6;
create table dmr_dev.bxy_tmp6 as
select
    user_id, case_id, session_id, dt, min(url) as url, min(timestamp_s) as timestamp_s
from 
    dmr_dev.bxy_tmp5
where 
    user_id > 0
group by 
    user_id, case_id, session_id, dt
order by 
    user_id, case_id, session_id, dt
;

select * from dmr_dev.bxy_tmp6;

use dmr_dev;
drop table if exists dmr_dev.bxy_tmp7;
create table dmr_dev.bxy_tmp7 as
select
    *, 
    lag(timestamp_s, 1) over(partition by user_id, dt order by timestamp_s) as last_timestamp_s
from
    dmr_dev.bxy_tmp6;

select * from dmr_dev.bxy_tmp7;

use dmr_dev;
drop table if exists dmr_dev.bxy_tmp8;
create table dmr_dev.bxy_tmp8 as
select
    *, 
    timestamp_s - last_timestamp_s as timediff
from
    dmr_dev.bxy_tmp7;

select count(Case when timediff < 5 then 1 else null end), count(*) from dmr_dev.bxy_tmp8;




