use dmr_dev;
drop table if exists dmr_dev.bxy_tmp1;
create table dmr_dev.bxy_tmp1 as
select 
    user_id, case_id, dt, url, timestamp_s
from 
    dmr_dev.bxy_action_sequence_pattern_mining_1;

--
use dmr_dev;
drop table if exists dmr_dev.bxy_tmp2;
create table dmr_dev.bxy_tmp2 as
select
    user_id,
    last_value(case_id, True) over(partition by user_id, dt order by timestamp_s) as case_id,
    dt, url, timestamp_s
from 
    dmr_dev.bxy_tmp1;

use dmr_dev;
drop table if exists dmr_dev.bxy_tmp3;
create table dmr_dev.bxy_tmp3 as
select
    user_id, case_id,
    lag(case_id, 1) over(partition by user_id, dt order by timestamp_s) as lag_case_id,
    dt, url, timestamp_s
from 
    dmr_dev.bxy_tmp2;

use dmr_dev;
drop table if exists dmr_dev.bxy_tmp4;
create table dmr_dev.bxy_tmp4 as
select
    user_id, case_id, lag_case_id,
    Case When case_id is not null and lag_case_id is not null and case_id <> lag_case_id then 1 Else 0 End as session_flag,
    dt, url, timestamp_s
from 
    dmr_dev.bxy_tmp3;

use dmr_dev;
drop table if exists dmr_dev.bxy_tmp5;
create table dmr_dev.bxy_tmp5 as
select
    user_id, case_id,
    sum(session_flag) OVER (partition by user_id, dt order by timestamp_s ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as session_id,
    dt, url, timestamp_s
from 
    dmr_dev.bxy_tmp4;

select * from dmr_dev.bxy_tmp1;
select * from dmr_dev.bxy_tmp2;
select * from dmr_dev.bxy_tmp3;
select * from dmr_dev.bxy_tmp4;
select * from dmr_dev.bxy_tmp5;










