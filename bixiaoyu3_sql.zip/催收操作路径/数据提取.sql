select * from odm.odm_brs_jr_jmqsink_jrflow_cic_i_d where dt='2020-10-20' and url like '%cloyunchu%';

--**按页面分析
--统计期 20201116-20201120

set mapreduce.map.memory.mb=8192;
set mapreduce.map.java.opts=-Xmx7200m;
--获取活跃用户的记录
use dmr_dev;
drop table if exists dmr_dev.bxy_action_sequence_pattern_mining_1;
create table dmr_dev.bxy_action_sequence_pattern_mining_1 as
select 
    cast(get_json_object(v,'$.userId') as int) as user_id,
    cast(get_json_object(v,'$.caseId') as string) as case_id,
    cast(get_json_object(v,'$.custKey') as string) cust_pin,
    (Case When url like '%login%' then 'login'
          When url like '%dashboard%' then 'dashboard'
          When url like '%caseControl%' then 'caseControl'
          When url like '%urgeTaskPanel%' then 'urgeTaskPanel'
          When url like '%urgeTaskQueueUpdate%' then 'urgeTaskQueueUpdate'
          When url like '%predictCallPanel%' then 'predictCallPanel'
          When url like '%predictCallQueue%' then 'predictCallQueue'
          When url like '%urgeTaskQueryQueue%' then 'urgeTaskQueryQueue'
          When url like '%repayMain%' then 'repayMain'
          Else 'other' End) as url,
    url as url_link,
    cls as action,
    cast(get_json_object(v,'$.productType') as string) as product,
    stm/1000 as timestamp_s,
    dt
from 
    odm.odm_brs_jr_jmqsink_jrflow_cic_i_d
where 
    dt >= '2020-11-01' and dt <= '2020-11-30' and url like '%cloyunchu%';

--select * from dmr_dev.bxy_action_sequence_pattern_mining_1 where dt = '2020-11-09' and user_id = 14071;
--select count(*) from dmr_dev.bxy_action_sequence_pattern_mining_1;

--用户统计 统计期内有管理操作的user_id（管理员）
use dmr_dev;
drop table if exists dmr_dev.bxy_action_sequence_pattern_mining_userlist;
create table dmr_dev.bxy_action_sequence_pattern_mining_userlist as
select 
    DISTINCT user_id
from
    dmr_dev.bxy_action_sequence_pattern_mining_1
where 
    dt >= '2020-11-01' and dt <= '2020-11-30' and url in ('predictCallPanel', 'predictCallQueue');


set mapreduce.map.memory.mb=8192; 
set mapreduce.map.java.opts=-Xmx7200m;
use dmr_dev;
drop table if exists dmr_dev.bxy_action_sequence_pattern_mining_2;
create table dmr_dev.bxy_action_sequence_pattern_mining_2 as
select
    *
from 
    (select 
        *, 
        row_number() over(partition by user_id, dt order by timestamp_s) as ra
    from 
        dmr_dev.bxy_action_sequence_pattern_mining_1) tmp1
where
    user_id > 0 and 
    NOT EXISTS (select * from dmr_dev.bxy_action_sequence_pattern_mining_userlist tmp2 where tmp1.user_id = tmp2.user_id )
order by --排序为了后续collect_list的顺序
    user_id, dt, ra;

--select * from dmr_dev.bxy_action_sequence_pattern_mining_2;
--select count(*) from dmr_dev.bxy_action_sequence_pattern_mining_2;

set mapreduce.map.memory.mb=8192; 
set mapreduce.map.java.opts=-Xmx7200m;
use dmr_dev;
drop table if exists dmr_dev.bxy_action_sequence_pattern_mining_3;
create table dmr_dev.bxy_action_sequence_pattern_mining_3 as
select 
    a.*
from
    dmr_dev.bxy_action_sequence_pattern_mining_2 a
where
    not exists (select 1 
    from dmr_dev.bxy_action_sequence_pattern_mining_2 b 
    where a.dt = b.dt and a.user_id = b.user_id and a.ra = b.ra-1 and b.url = a.url)
order by 
    user_id, ra;

--select * from dmr_dev.bxy_action_sequence_pattern_mining_3;
--select count(*) from dmr_dev.bxy_action_sequence_pattern_mining_3;

--统计时长和次数，去除other类
use dmr_dev;
drop table if exists dmr_dev.bxy_action_sequence_pattern_mining_4;
create table dmr_dev.bxy_action_sequence_pattern_mining_4 as
select
    user_id, url, action, 
    timestamp_s - timestamp_s_before as timediff,
    ra, ra - ra_before as radiff,
    dt
from
    (select 
        *, 
        lag(timestamp_s, 1, 0) over(partition by user_id, dt order by ra) as timestamp_s_before,
        lag(ra, 1, 0) over(partition by user_id, dt order by ra) as ra_before
    from 
        dmr_dev.bxy_action_sequence_pattern_mining_3) tmp;

--select * from dmr_dev.bxy_action_sequence_pattern_mining_4;
--select count(*) from dmr_dev.bxy_action_sequence_pattern_mining_4;

--合并url, action
use dmr_dev;
drop table if exists dmr_dev.bxy_action_sequence_pattern_mining_5;
create table dmr_dev.bxy_action_sequence_pattern_mining_5 as
select
    user_id, dt, collect_list(url) as url_list, collect_list(action) as action_list
from 
    dmr_dev.bxy_action_sequence_pattern_mining_4
group by 
    user_id, dt;

--select * from dmr_dev.bxy_action_sequence_pattern_mining_5;
--select count(*) from dmr_dev.bxy_action_sequence_pattern_mining_5;

--催收员表现
desc dmr_c.dmrc_cs_qzm_collector_sdpamt_amount_a_d;
select * from dmr_c.dmrc_cs_qzm_collector_sdpamt_amount_a_d;
select * from dmr_dev.dx_collector_gb_nov_01;

--还款表现分位数
use dmr_dev;
drop table if exists dmr_dev.bxy_collector_gb_nov_02;
create table dmr_dev.bxy_collector_gb_nov_02 as
select 
    tmp1.*, tmp2.`(location)?+.+`
from 
    dmr_dev.dx_collector_gb_nov_01 tmp1 left join 
    (select 
        location, 
        percentile_approx(repay_m_rate, 0.3) as m_quantile_30,
        percentile_approx(repay_m_rate, 0.7) as m_quantile_70,
        percentile_approx(repay_c_rate, 0.3) as c_quantile_30,
        percentile_approx(repay_c_rate, 0.7) as c_quantile_70
    from 
        dmr_dev.dx_collector_gb_nov_01
    group by 
        location) tmp2 on tmp1.location = tmp2.location;

--select * from dmr_dev.bxy_collector_gb_nov_02;
--select count(*) from dmr_dev.bxy_collector_gb_nov_02;

--两种方式均在70%分位以上，定义为优秀 1
--两种方式均在30%分位以下，定义为差 0
--其他定义为 -1
use dmr_dev;
drop table if exists dmr_dev.bxy_collector_gb_nov_03;
create table dmr_dev.bxy_collector_gb_nov_03 as
select 
    *,
    Case When (repay_m_rate < m_quantile_30 and repay_c_rate < c_quantile_30) then 0
         When (repay_m_rate > m_quantile_70 and repay_c_rate > c_quantile_70) then 1
         Else -1 End as label
from 
    dmr_dev.bxy_collector_gb_nov_02;

--select * from dmr_dev.bxy_collector_gb_nov_03;
--select count(*) from dmr_dev.bxy_collector_gb_nov_03;

use dmr_dev;
drop table if exists dmr_dev.bxy_action_sequence_pattern_mining_6;
create table dmr_dev.bxy_action_sequence_pattern_mining_6 as
select
    tmp1.*, tmp2.label
from 
    dmr_dev.bxy_action_sequence_pattern_mining_5 tmp1 left join
    (select 
        collector_id as user_id, min(label) as label
    from
        dmr_dev.bxy_collector_gb_nov_03
    group by 
        collector_id
    ) tmp2 on tmp1.user_id = tmp2.user_id;

--select * from dmr_dev.bxy_action_sequence_pattern_mining_6;
--select count(*) from dmr_dev.bxy_action_sequence_pattern_mining_6;



