show partitions dmr_c.dmrc_model_t04_collect_c_score_v3_s_d;
desc dmr_c.dmrc_model_t04_collect_c_score_v3_s_d;

--按日抽样
use dmr_dev;
DROP TABLE if EXISTS dmr_dev.bxy_c_card_daily_analysis_sample;
CREATE TABLE if not exists dmr_dev.bxy_c_card_daily_analysis_sample as


--分位数分布
SELECT 
    dt,
    percentile_approx(std_score, 0.1) AS 10percent_score, 
    percentile_approx(std_score, 0.2) AS 20percent_score, 
    percentile_approx(std_score, 0.3) AS 30percent_score, 
    percentile_approx(std_score, 0.4) AS 40percent_score, 
    percentile_approx(std_score, 0.5) AS 50percent_score, 
    percentile_approx(std_score, 0.6) AS 60percent_score, 
    percentile_approx(std_score, 0.7) AS 70percent_score, 
    percentile_approx(std_score, 0.8) AS 80percent_score, 
    percentile_approx(std_score, 0.9) AS 90percent_score
FROM 
    dmr_c.dmrc_model_t04_collect_c_score_v3_s_d
WHERE 
    dt > '2020-09-10'
GROUP BY 
    dt
ORDER BY 
    dt DESC;


----分数等距分箱
--白条
Select 
    a.dt, score_group, count(*)
From 
    (Select 
        pin, dt,
        (Case When std_score_cuiji <= 480 then 1
             When std_score_cuiji <= 510 then 2
             When std_score_cuiji <= 540 then 3
             When std_score_cuiji <= 570 then 4
             When std_score_cuiji <= 600 then 5
             When std_score_cuiji <= 630 then 6
             When std_score_cuiji <= 660 then 7
             When std_score_cuiji <= 690 then 8
             When std_score_cuiji <= 720 then 9
             When std_score_cuiji > 720 then 10
             Else null End) as score_group
    From 
        dmr_c.dmrc_model_t04_collect_c_score_v3_s_d) a left join
    (Select 
        * 
    From 
        dmr_c.dmrc_cs_bt_overdays_amt_s_d 
    Where 
        dt >= '2020-07-01' and overdue_days > 0 and cur_bal > 0) b on a.pin = b.pin and a.dt = date_sub(b.dt, 2) 
Where 
    b.pin is not null
Group By 
    a.dt, score_group;

--金条
Select 
    a.dt, score_group, count(*)
From 
    (Select 
        pin, dt,
        (Case When std_score_cuiji <= 480 then 1
             When std_score_cuiji <= 510 then 2
             When std_score_cuiji <= 540 then 3
             When std_score_cuiji <= 570 then 4
             When std_score_cuiji <= 600 then 5
             When std_score_cuiji <= 630 then 6
             When std_score_cuiji <= 660 then 7
             When std_score_cuiji <= 690 then 8
             When std_score_cuiji <= 720 then 9
             When std_score_cuiji > 720 then 10
             Else null End) as score_group
    From 
        dmr_c.dmrc_model_t04_collect_c_score_v3_s_d) a left join
    (Select 
        * 
    From 
        dmr_c.dmrc_cs_jt_overdays_amt_s_d 
    Where 
        dt >= '2020-07-01' and overdue_days > 0 and cur_bal > 0) b on a.pin = b.pin and a.dt = date_sub(b.dt, 2) 
Where 
    b.pin is not null
Group By 
    a.dt, score_group;













    
    
