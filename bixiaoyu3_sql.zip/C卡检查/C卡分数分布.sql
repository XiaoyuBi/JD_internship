desc dmr_c.dmrc_model_t04_collect_c_score_v3_s_d;

Select * From dmr_c.dmrc_model_t04_collect_c_score_v3_s_d where dt = '2020-08-01' limit 100;

--分数分布
Select 
    ovd_stage,
    sum(Case When score_interval = '450-480' Then 1 Else 0 End) as `450-480`,
    sum(Case When score_interval = '480-510' Then 1 Else 0 End) as `480-510`,
    sum(Case When score_interval = '510-540' Then 1 Else 0 End) as `510-540`,
    sum(Case When score_interval = '540-570' Then 1 Else 0 End) as `540-570`,
    sum(Case When score_interval = '570-600' Then 1 Else 0 End) as `570-600`,
    sum(Case When score_interval = '600-630' Then 1 Else 0 End) as `600-630`,
    sum(Case When score_interval = '630-660' Then 1 Else 0 End) as `630-660`,
    sum(Case When score_interval = '660-690' Then 1 Else 0 End) as `660-690`,
    sum(Case When score_interval = '690-720' Then 1 Else 0 End) as `690-720`,
    sum(Case When score_interval = '720-750' Then 1 Else 0 End) as `720-750`
From
    (Select
        (case when jt_cur_overdue_days>0 and jt_cur_overdue_days<=30 then 'M1'
              when jt_cur_overdue_days>0 and jt_cur_overdue_days<=60 then 'M2'
              when jt_cur_overdue_days>0 and jt_cur_overdue_days<=90 then 'M3'
              when jt_cur_overdue_days>0 and jt_cur_overdue_days<=120 then 'M4'
              when jt_cur_overdue_days>0 and jt_cur_overdue_days<=150 then 'M5'
              when jt_cur_overdue_days>0 and jt_cur_overdue_days<=180 then 'M6'
              when jt_cur_overdue_days>0 and jt_cur_overdue_days<=210 then 'M7'
              when jt_cur_overdue_days>0 and jt_cur_overdue_days<=300 then '211-300'
              when jt_cur_overdue_days>0 and jt_cur_overdue_days<=390 then '301-390'
              when jt_cur_overdue_days>390 then '391+' 
              else 'M0' end) as ovd_stage,
        (case when std_score >= 450 and std_score < 480 then '450-480'
              when std_score >= 480 and std_score < 510 then '480-510'
              when std_score >= 510 and std_score < 540 then '510-540'
              when std_score >= 540 and std_score < 570 then '540-570'
              when std_score >= 570 and std_score < 600 then '570-600'
              when std_score >= 600 and std_score < 630 then '600-630'
              when std_score >= 630 and std_score < 660 then '630-660'
              when std_score >= 660 and std_score < 690 then '660-690'
              when std_score >= 690 and std_score < 720 then '690-720'
              when std_score >= 720 and std_score < 750 then '720-750' end) as score_interval,
        (case when std_score_cuiji >= 450 and std_score_cuiji < 480 then '450-480'
              when std_score_cuiji >= 480 and std_score_cuiji < 510 then '480-510'
              when std_score_cuiji >= 510 and std_score_cuiji < 540 then '510-540'
              when std_score_cuiji >= 540 and std_score_cuiji < 570 then '540-570'
              when std_score_cuiji >= 570 and std_score_cuiji < 600 then '570-600'
              when std_score_cuiji >= 600 and std_score_cuiji < 630 then '600-630'
              when std_score_cuiji >= 630 and std_score_cuiji < 660 then '630-660'
              when std_score_cuiji >= 660 and std_score_cuiji < 690 then '660-690'
              when std_score_cuiji >= 690 and std_score_cuiji < 720 then '690-720'
              when std_score_cuiji >= 720 and std_score < 750 then '720-750' end) as score_cuiji_interval   
    From 
        dmr_c.dmrc_model_t04_collect_c_score_v3_s_d
    Where 
        dt = '2020-06-01')
Group By 
    ovd_stage;
    
--逐日PSI分布分析
select * from dmr_c.dmrc_model_t04_collect_c_score_v3_s_d where dt = '2020-08-15';
select * from dmr_dev.dx_cscore_batch_works where dt = '2020-05-01';
    
--每个dt抽样10000条分数
--白条
use dmr_dev;
DROP TABLE if EXISTS dmr_dev.bxy_c_card_bt_psi_analysis_sample;
CREATE TABLE if not exists dmr_dev.bxy_c_card_bt_psi_analysis_sample as
Select
    dt, org_score, org_score_cuiji
From
    (Select 
        dt, pin, org_score, org_score_cuiji,
        rank() over(partition by dt order by rand()) as rk
    From 
        dmr_dev.dx_cscore_batch_works
    Where 
        bt_cur_overdue_days > 0) t
Where
    rk <= 10000;

--金条
use dmr_dev;
DROP TABLE if EXISTS dmr_dev.bxy_c_card_jt_psi_analysis_sample;
CREATE TABLE if not exists dmr_dev.bxy_c_card_jt_psi_analysis_sample as
Select
    dt, org_score, org_score_cuiji
From
    (Select 
        dt, pin, org_score, org_score_cuiji,
        rank() over(partition by dt order by rand()) as rk
    From 
        dmr_dev.dx_cscore_batch_works
    Where 
        jt_cur_overdue_days > 0) t
Where
    rk <= 10000;
    
select count(*) from dmr_dev.bxy_c_card_bt_psi_analysis_sample;
select count(*) from dmr_dev.bxy_c_card_jt_psi_analysis_sample;
    

-- 0814PSI 异常排查
--select * from dmr_c.dmrc_model_t04_collect_c_score_v3_s_d where dt = '2020-08-14' and jt_cur_overdue_days > 0;
--desc dmr_c.dmrc_model_t04_collect_c_score_v3_features_s_d;
set mapreduce.map.memory.mb=8192; 
set mapreduce.map.java.opts=-Xmx7200m;
use dmr_dev;
DROP TABLE if EXISTS dmr_dev.bxy_c_card_jt_psi_anomaly_analysis_sample1;
CREATE TABLE if not exists dmr_dev.bxy_c_card_jt_psi_anomaly_analysis_sample1 as
Select 
    pin, dt,
    cv2btf11166,	cv3f7,	cv2jtf1407,	cv3f4086,	cv2btf11161,	cv2btf7988,	cv2jtf987,	cv3f3889,	cv2btf11150,	cv3f3863,	cv3f3881,	cv3f3895,	cjf5181,cv2btf10802,	device_brand_cnt,	cv3f3905,	cv2jtf218,	cjf5179,	cv3f3965,	cv3f9,	cv2btf11158,	cv2btf11163,	cv3f3803,	cjf5711,	cv2jtf379,cv3f6,cjf5193,	cv2btf11177,	cv2jtf24,	cv3f3991,	cjf6009,	cjf5740,	cv3f3907,	cv3f758,	cv2btf11137,	cjf5186,	cv2btf10955,	cv3f3823,cv3f4100,	cv3f777,	cjf5599,	cjf5719,	cv2btf11167,	cv3f1537,	cv3f3983,	cv2jtf128,	cv3f3918,	cv3f3967,	cv3f877,	cjf5768
From 
    dmr_c.dmrc_model_t04_collect_c_score_v3_features_s_d
Where 
    dt = '2020-11-30' and 
    pin in (Select pin From dmr_c.dmrc_model_t04_collect_c_score_v3_s_d Where dt = '2020-11-30' and bt_cur_overdue_days > 0 Order By rand() limit 20000);


use dmr_dev;
DROP TABLE if EXISTS dmr_dev.bxy_c_card_jt_psi_anomaly_analysis_sample2;
CREATE TABLE if not exists dmr_dev.bxy_c_card_jt_psi_anomaly_analysis_sample2 as
Select 
    pin, dt,
    cv2btf11166,	cv3f7,	cv2jtf1407,	cv3f4086,	cv2btf11161,	cv2btf7988,	cv2jtf987,	cv3f3889,	cv2btf11150,	cv3f3863,	cv3f3881,	cv3f3895,	cjf5181,cv2btf10802,	device_brand_cnt,	cv3f3905,	cv2jtf218,	cjf5179,	cv3f3965,	cv3f9,	cv2btf11158,	cv2btf11163,	cv3f3803,	cjf5711,	cv2jtf379,cv3f6,cjf5193,	cv2btf11177,	cv2jtf24,	cv3f3991,	cjf6009,	cjf5740,	cv3f3907,	cv3f758,	cv2btf11137,	cjf5186,	cv2btf10955,	cv3f3823,cv3f4100,	cv3f777,	cjf5599,	cjf5719,	cv2btf11167,	cv3f1537,	cv3f3983,	cv2jtf128,	cv3f3918,	cv3f3967,	cv3f877,	cjf5768
From 
    dmr_c.dmrc_model_t04_collect_c_score_v3_features_s_d
Where 
    dt = '2020-12-01' and pin in (select pin from dmr_dev.bxy_c_card_jt_psi_anomaly_analysis_sample1);

use dmr_dev;
DROP TABLE if EXISTS dmr_dev.bxy_c_card_jt_psi_anomaly_analysis_sample3;
CREATE TABLE if not exists dmr_dev.bxy_c_card_jt_psi_anomaly_analysis_sample3 as
Select 
    pin, dt,
    cv2btf11166,	cv3f7,	cv2jtf1407,	cv3f4086,	cv2btf11161,	cv2btf7988,	cv2jtf987,	cv3f3889,	cv2btf11150,	cv3f3863,	cv3f3881,	cv3f3895,	cjf5181,cv2btf10802,	device_brand_cnt,	cv3f3905,	cv2jtf218,	cjf5179,	cv3f3965,	cv3f9,	cv2btf11158,	cv2btf11163,	cv3f3803,	cjf5711,	cv2jtf379,cv3f6,cjf5193,	cv2btf11177,	cv2jtf24,	cv3f3991,	cjf6009,	cjf5740,	cv3f3907,	cv3f758,	cv2btf11137,	cjf5186,	cv2btf10955,	cv3f3823,cv3f4100,	cv3f777,	cjf5599,	cjf5719,	cv2btf11167,	cv3f1537,	cv3f3983,	cv2jtf128,	cv3f3918,	cv3f3967,	cv3f877,	cjf5768
From 
    dmr_c.dmrc_model_t04_collect_c_score_v3_features_s_d
Where 
    dt = '2020-12-02' and pin in (select pin from dmr_dev.bxy_c_card_jt_psi_anomaly_analysis_sample1);

--Select count(*) From dmr_dev.bxy_c_card_jt_psi_anomaly_analysis_sample1;
--Select count(*) From dmr_dev.bxy_c_card_jt_psi_anomaly_analysis_sample2;
    
    
    
    
    
    
    
    
    
    
    
    

