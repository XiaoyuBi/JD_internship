---- 逾期信息整合
--白条样本
use dmr_dev;
drop table if exists dmr_dev.bxy_xc_analysis_c_label_t30_bt;
create table dmr_dev.bxy_xc_analysis_c_label_t30_bt as 
select 
tab1.*, tab2.overdue_days overdue_days_30, tab2.overdue_amt overdue_amt_30,
tab2.cur_bal cur_bal_30,
case when tab1.overdue_days<=30 then 'M1'
    when tab1.overdue_days<=60 then 'M2'
    when tab1.overdue_days<=90 then 'M3'
    when tab1.overdue_days<=120 then 'M4'
    when tab1.overdue_days<=150 then 'M5'
    when tab1.overdue_days<=180 then 'M6'
    when tab1.overdue_days<=210 then 'M7'
    when tab1.overdue_days<=300 then '211-300'
    when tab1.overdue_days<=390 then '301-390'
    else '391+' end as ovd_stage,
case when tab2.overdue_days>=tab1.overdue_days+30 then 0 
when tab2.overdue_days is null then 1.1--30天后没有逾期天数，证明期间已还清，不升期为1
when tab1.overdue_days<=30 and tab2.overdue_days<30 then 1.2--M1循环
when tab1.overdue_days>30 and tab2.overdue_days<30 then 1.3--M2及以上还清历史但逾期1期
when tab2.overdue_days<tab1.overdue_days+30 then 1.4--30天内部分还款，不升期为1
else null end as target_sqr--否则升期，为0
from (
    select *
    from dmr_c.dmrc_cs_bt_overdays_amt_s_d
    where dt >= '2020-08-01'  and dt <= '2020-09-01'
    and overdue_days>0 and cur_bal>0) tab1
left join 
(
select *
from dmr_c.dmrc_cs_bt_overdays_amt_s_d 
where dt>='2020-08-01'
and overdue_days>0)tab2 on 
tab1.pin=tab2.pin and date_add(tab1.dt,30)=tab2.dt;

--金条样本
use dmr_dev;
drop table if exists dmr_dev.bxy_xc_analysis_c_label_t30_jt;
create table dmr_dev.bxy_xc_analysis_c_label_t30_jt as 
select 
tab1.*, tab2.overdue_days overdue_days_30, tab2.overdue_amt overdue_amt_30,
tab2.cur_bal cur_bal_30,
case when tab1.overdue_days<=30 then 'M1'
    when tab1.overdue_days<=60 then 'M2'
    when tab1.overdue_days<=90 then 'M3'
    when tab1.overdue_days<=120 then 'M4'
    when tab1.overdue_days<=150 then 'M5'
    when tab1.overdue_days<=180 then 'M6'
    when tab1.overdue_days<=210 then 'M7'
    when tab1.overdue_days<=300 then '211-300'
    when tab1.overdue_days<=390 then '301-390'
    else '391+' end as ovd_stage,
case when tab2.overdue_days>=tab1.overdue_days+30 then 0 
when tab2.overdue_days is null then 1.1--30天后没有逾期天数，证明期间已还清，不升期为1
when tab1.overdue_days<=30 and tab2.overdue_days<30 then 1.2--M1循环
when tab1.overdue_days>30 and tab2.overdue_days<30 then 1.3--M2及以上还清历史但逾期1期
when tab2.overdue_days<tab1.overdue_days+30 then 1.4--30天内部分还款，不升期为1
else null end as target_sqr--否则升期，为0
from (
    select *
    from dmr_c.dmrc_cs_jt_overdays_amt_s_d
    where dt >= '2020-08-01'  and dt <= '2020-09-01'
    and overdue_days>0 and cur_bal>0) tab1
left join 
(
select *
from dmr_c.dmrc_cs_jt_overdays_amt_s_d 
where dt>='2020-08-01'
and overdue_days>0)tab2 on 
tab1.pin=tab2.pin and date_add(tab1.dt,30)=tab2.dt;

--汇总
use dmr_dev;
drop table if exists dmr_dev.bxy_xc_analysis_c_label_t30_btjt;
create table dmr_dev.bxy_xc_analysis_c_label_t30_btjt as 
    select z.*,
    case when tot_overdue_days<=30 then 'M1'
    when tot_overdue_days<=60 then 'M2'
    when tot_overdue_days<=90 then 'M3'
    when tot_overdue_days<=120 then 'M4'
    when tot_overdue_days<=150 then 'M5'
    when tot_overdue_days<=180 then 'M6'
    when tot_overdue_days<=210 then 'M7'
    when tot_overdue_days<=300 then '211-300'
    when tot_overdue_days<=390 then '301-390'    
    else '391+' end as tot_ovd_stage from
    (select c.pin, c.dt, a.target_sqr bt_target_sqr, b.target_sqr jt_target_sqr,
    a.ovd_stage bt_ovd_stage, b.ovd_stage jt_ovd_stage, 
    case when a.overdue_days is null and b.overdue_days is not null then b.overdue_days
    when a.overdue_days is not null and b.overdue_days is null then a.overdue_days
    else if(a.overdue_days>b.overdue_days,a.overdue_days,b.overdue_days) end tot_overdue_days
    from (
        select pin, dt from dmr_dev.bxy_xc_analysis_c_label_t30_bt 
        union
        select pin, dt from dmr_dev.bxy_xc_analysis_c_label_t30_jt
    ) c left join dmr_dev.bxy_xc_analysis_c_label_t30_bt a 
    on c.pin=a.pin and c.dt=a.dt left join
    dmr_dev.bxy_xc_analysis_c_label_t30_jt b 
    on c.pin=b.pin and c.dt=b.dt) z;
    
----xc原始样本与逾期阶段合并
use dmr_dev;
drop table if exists dmr_dev.bxy_xc_analysis1;
create table dmr_dev.bxy_xc_analysis1 as 
Select 
    t1.*,
    (Case When t1.product = '京东白条' then t2.bt_ovd_stage
         When t1.product = '京东金条' then t2.jt_ovd_stage End) as ovd_stage
From 
    dmr_dev.bxy_temp_pin_list t1 Left Join
    dmr_dev.bxy_xc_analysis_c_label_t30_btjt t2 on t1.pin = t2.pin and t1.dt = t2.dt;
    
----与C卡分合并
use dmr_dev;
drop table if exists dmr_dev.bxy_xc_analysis2;
create table dmr_dev.bxy_xc_analysis2 as 
Select 
    t1.*, t2.std_score as c_score
From 
    dmr_dev.bxy_xc_analysis1 t1 left join 
    dmr_c.dmrc_model_t04_collect_c_score_v3_s_d t2 on t1.pin = t2.pin and date_add(t1.dt, 2) = t2.dt;

----与最佳介入时点分合并
--select * from dmr_c.dmrc_model_t04_collect_intervene_timing_recommendation_s_d;
use dmr_dev;
drop table if exists dmr_dev.bxy_xc_analysis3;
create table dmr_dev.bxy_xc_analysis3 as 
Select 
    t1.*, t2.score as timing_score
From 
    dmr_dev.bxy_xc_analysis2 t1 left join 
    dmr_c.dmrc_model_t04_collect_intervene_timing_recommendation_s_d t2 
    on t1.pin = t2.pin and date_add(t1.dt, 2) = t2.dt and substring(t1.product, -2, 2) = t2.product;

----与逾期金额合并(仅白条)
--select * from dmr_c.dmrc_cs_bt_overdays_amt_s_d;
use dmr_dev;
drop table if exists dmr_dev.bxy_xc_analysis4;
create table dmr_dev.bxy_xc_analysis4 as 
Select 
    t1.*, t2.overdue_amt
From 
    dmr_dev.bxy_xc_analysis3 t1 left join 
    dmr_c.dmrc_cs_bt_overdays_amt_s_d t2 on t1.pin = t2.pin and t1.dt = t2.dt;

--与还款金额合并 t3
--select * from dmr_c.dmrc_cs_repayment_a_d order by rand();
use dmr_dev;
drop table if exists dmr_dev.bxy_xc_analysis5_1;
create table dmr_dev.bxy_xc_analysis5_1 as 
Select 
    t1.pin,t1.product,case_type,xc_score,t1.dt,ovd_stage,c_score,timing_score,overdue_amt, 
    sum(t2.amount) as pay_amount_t3
From 
    dmr_dev.bxy_xc_analysis4 t1 left join 
    dmr_c.dmrc_cs_repayment_a_d t2 on 
    t1.pin = t2.pin and substring(t1.product, -2, 2) = t2.product and t2.paydate >= t1.dt and t2.paydate <= date_add(t1.dt, 3)
Group By 
    t1.pin,t1.product,case_type,xc_score,t1.dt,ovd_stage,c_score,timing_score,overdue_amt;

--与还款金额合并 t15
use dmr_dev;
drop table if exists dmr_dev.bxy_xc_analysis5_2;
create table dmr_dev.bxy_xc_analysis5_2 as 
Select 
    t1.pin,t1.product,case_type,xc_score,t1.dt,ovd_stage,c_score,timing_score,overdue_amt,pay_amount_t3,
    sum(t2.amount) as pay_amount_t15
From 
    dmr_dev.bxy_xc_analysis5_1 t1 left join 
    dmr_c.dmrc_cs_repayment_a_d t2 on 
    t1.pin = t2.pin and substring(t1.product, -2, 2) = t2.product and t2.paydate >= t1.dt and t2.paydate <= date_add(t1.dt, 15)
Group By 
    t1.pin,t1.product,case_type,xc_score,t1.dt,ovd_stage,c_score,timing_score,overdue_amt,pay_amount_t3;

--与还款金额合并 t30
use dmr_dev;
drop table if exists dmr_dev.bxy_xc_analysis5_3;
create table dmr_dev.bxy_xc_analysis5_3 as 
Select 
    t1.pin,t1.product,case_type,xc_score,t1.dt,ovd_stage,c_score,timing_score,overdue_amt,pay_amount_t3,pay_amount_t15,
    sum(t2.amount) as pay_amount_t30
From 
    dmr_dev.bxy_xc_analysis5_2 t1 left join 
    dmr_c.dmrc_cs_repayment_a_d t2 on t1.dt <= '2020-08-20' and --因为部分表现期未满
    t1.pin = t2.pin and substring(t1.product, -2, 2) = t2.product and t2.paydate >= t1.dt and t2.paydate <= date_add(t1.dt, 30)
Group By 
    t1.pin,t1.product,case_type,xc_score,t1.dt,ovd_stage,c_score,timing_score,overdue_amt,pay_amount_t3,pay_amount_t15;

--还款标签
use dmr_dev;
drop table if exists dmr_dev.bxy_xc_analysis6;
create table dmr_dev.bxy_xc_analysis6 as 
Select
    *,
    (Case When pay_amount_t3 is not null then 1 Else 0 End) as c_label_t3,
    (Case When pay_amount_t15 is not null then 1 Else 0 End) as c_label_t15,
    (Case When pay_amount_t30 is not null then 1 Else 0 End) as c_label_t30
From 
    dmr_dev.bxy_xc_analysis5_3;
    
--委案表 legalorg = '安徽信晨' tel_amt
--Select * from dmr_c.dmrc_cs_tel_work_a_d;
--与“委案月最大”逾期金额合并
use dmr_dev;
drop table if exists dmr_dev.bxy_xc_analysis7;
create table dmr_dev.bxy_xc_analysis7 as 
Select 
    t1.pin,t1.product,t1.case_type,t1.xc_score,t1.dt,t1.ovd_stage,t1.c_score,t1.timing_score,t1.overdue_amt,
    t1.pay_amount_t3,t1.pay_amount_t15,t1.pay_amount_t30,t1.c_label_t3,t1.c_label_t15,t1.c_label_t30, 
    max(t2.tel_amt) as overdue_amt_tel
From 
    dmr_dev.bxy_xc_analysis6 t1 Left Join 
    (Select 
        pin, product_id, substring(begin_month, 6) as month, tel_amt
     From 
        dmr_c.dmrc_cs_tel_work_a_d
     Where 
        legalorg = '安徽信晨' and substring(begin_month, 1, 4) = '2020') t2 
        on t1.pin = t2.pin and substring(t1.product, -2, 2) = t2.product_id and substring(t1.case_type, 1, 1) = t2.month
Group By 
    t1.pin,t1.product,t1.case_type,t1.xc_score,t1.dt,t1.ovd_stage,t1.c_score,t1.timing_score,t1.overdue_amt,
    t1.pay_amount_t3,t1.pay_amount_t15,t1.pay_amount_t30,t1.c_label_t3,t1.c_label_t15,t1.c_label_t30;

Select count(*) From dmr_dev.bxy_xc_analysis7;
Select * From dmr_dev.bxy_xc_analysis7;

------------------------------------------------------------------------------------------

----概览
--月份
--进件,平均分,-1计数
Select
    product, substring(case_type, 1, 1) as month,
    count(*),
    sum(Case When xc_score > 0 then xc_score Else 0 End) / sum(Case When xc_score > 0 then 1 Else 0 End),
    sum(Case When xc_score < 0 then 1 Else 0 End)
From 
    dmr_dev.bxy_xc_analysis7
Group By 
    product, substring(case_type, 1, 1)
Order By 
    product, substring(case_type, 1, 1);
--进件去重
Select
    product, substring(case_type, 1, 1) as month,
    count(*)
From 
    (Select pin, product, min(case_type) as case_type From dmr_dev.bxy_xc_analysis7 Group By pin, product) as tmp
Group By 
    product, substring(case_type, 1, 1)
Order By 
    product, substring(case_type, 1, 1);
--当月委案
Select 
    product_id, substring(begin_month, 6) as month,
    count(*)
From 
    dmr_c.dmrc_cs_tel_work_a_d
Where 
    legalorg = '安徽信晨' and substring(begin_month, 1, 4) = '2020'
Group By 
    product_id, substring(begin_month, 6)
Order By 
    product_id, substring(begin_month, 6);
    
--案件类别
--进件,平均分
Select
    product, substring(case_type, 2) as type,
    count(*),
    sum(Case When xc_score > 0 then xc_score Else 0 End) / sum(Case When xc_score > 0 then 1 Else 0 End),
    sum(Case When xc_score < 0 then 1 Else 0 End)
From 
    dmr_dev.bxy_xc_analysis7
Group By 
    product, substring(case_type, 2)
Order By 
    product, substring(case_type, 2);
--进件去重
Select
    product, substring(case_type, 2) as type,
    count(*)
From 
    (Select pin, product, min(case_type) as case_type From dmr_dev.bxy_xc_analysis7 Group By pin, product) as tmp
Group By 
    product, substring(case_type, 2)
Order By 
    product, substring(case_type, 2);
--类别委案
Select 
    product_id, location,
    count(*)
From 
    dmr_c.dmrc_cs_tel_work_a_d
Where 
    legalorg = '安徽信晨' and substring(begin_month, 1, 4) = '2020'
Group By 
    product_id, location
Order By 
    product_id, location;
    
--逾期阶段
--进件,平均分
Select
    product, ovd_stage,
    count(*),
    sum(Case When xc_score > 0 then xc_score Else 0 End) / sum(Case When xc_score > 0 then 1 Else 0 End),
    sum(Case When xc_score < 0 then 1 Else 0 End)
From 
    dmr_dev.bxy_xc_analysis7
Group By 
    product, ovd_stage
Order By 
    product, ovd_stage;
--进件去重
Select
    product, ovd_stage,
    count(*)
From 
    (Select pin, product, max(ovd_stage) as ovd_stage From dmr_dev.bxy_xc_analysis7 Group By pin, product) as tmp
Group By 
    product, ovd_stage
Order By 
    product, ovd_stage;
--逾期阶段委案
Select 
    product_id,
    case when days_delq<=30 then 'M1'
    when days_delq<=60 then 'M2'
    when days_delq<=90 then 'M3'
    when days_delq<=120 then 'M4'
    when days_delq<=150 then 'M5'
    when days_delq<=180 then 'M6'
    when days_delq<=210 then 'M7'
    when days_delq<=300 then '211-300'
    when days_delq<=390 then '301-390'
    else '391+' end as ovd_stage,
    count(*)
From 
    dmr_c.dmrc_cs_tel_work_a_d
Where 
    legalorg = '安徽信晨' and substring(begin_month, 1, 4) = '2020'
Group By 
    product_id, case when days_delq<=30 then 'M1'
    when days_delq<=60 then 'M2'
    when days_delq<=90 then 'M3'
    when days_delq<=120 then 'M4'
    when days_delq<=150 then 'M5'
    when days_delq<=180 then 'M6'
    when days_delq<=210 then 'M7'
    when days_delq<=300 then '211-300'
    when days_delq<=390 then '301-390'
    else '391+' end
Order By 
    product_id, case when days_delq<=30 then 'M1'
    when days_delq<=60 then 'M2'
    when days_delq<=90 then 'M3'
    when days_delq<=120 then 'M4'
    when days_delq<=150 then 'M5'
    when days_delq<=180 then 'M6'
    when days_delq<=210 then 'M7'
    when days_delq<=300 then '211-300'
    when days_delq<=390 then '301-390'
    else '391+' end;
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
