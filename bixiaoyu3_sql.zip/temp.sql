select count(pin), count(distinct pin) From dmr_c.dmrc_cs_jt_overdays_amt_s_d;

select * from odm.odm_risk_c_record_000_i_d limit 1000;

Select * From odm.odm_risk_c_record_sub_000_i_d limit 100;

Select * From odm.odm_risk_qt_case_info_i_d limit 100;

Select size(text) From dmr_dev.bxy_overdue_table_1_call_text limit 5;

Select size(split(regexp_replace(regexp_extract(text,'^\\[(.+)\\]$',1),'\\}\\,\\{', '\\}\\|\\|\\{'), '\\|\\|')) from dmr_dev.bxy_overdue_table_2 limit 10;

Select * From dmr_c.dmrc_cs_jt_overdays_amt_s_d
Where pin = 'jd_45ecab7941f5b';

Select regexp_extract(get_json_object(ext_info,'$.overdueAmount'), '([0-9]+)\\.([0-9]+)', 0) as overdue_amt From odm.odm_risk_c_record_000_i_d limit 10;
Select get_json_object(ext_info,'$.overdueAmount') as overdue_amt From odm.odm_risk_c_record_000_i_d limit 10;

Select Count(*) From dmr_dev.bxy_overdue_table_with_call_text;
Select Count(*) From dmr_dev.bxy_overdue_table_1;
Select * From odm.odm_risk_qt_case_info_i_d where cust_key = '029高陵县陈岐';
Select * From dmr_dev.bxy_overdue_table_2 where pin = '029高陵县陈岐';
Select * From dmr_dev.bxy_overdue_table_2_dropdup where pin = '029高陵县陈岐';
Select * From dmr_dev.bxy_overdue_table_2_merge where pin = '029高陵县陈岐';
Select * From dmr_dev.bxy_overdue_table_with_call_text where pin = '029高陵县陈岐';

Select * From odm.odm_risk_qt_case_info_i_d where cust_key = '1002102236-219522';
Select * From dmr_dev.bxy_overdue_table_2 where pin = '1002102236-219522';
Select * From dmr_dev.bxy_overdue_table_2_dropdup where pin = '1002102236-219522';
Select * From dmr_dev.bxy_overdue_table_2_merge where pin = '1002102236-219522';
Select * From dmr_dev.bxy_overdue_table_with_call_text where pin = '1002102236-219522';

select * from dmr_c.dmrc_cs_jt_overdays_amt_s_d where product = '白条' limit 100;

Select * From dmr_dev.bxy_overdue_table_with_call_text where pin = '029高陵县陈岐' limit 100;


Select * From dmr_dev.bxy_overdue_table_with_call_text_jieba limit 100;
Select size(user_jieba_text) From dmr_dev.bxy_overdue_table_with_call_text_jieba limit 100;

Select Case When array_contains(user_jieba_text, '对') then 1 Else 0 End
From dmr_dev.bxy_overdue_table_with_call_text_jieba
limit 10;

	
Select * From odm.odm_risk_qt_case_info_i_d where cust_key = '0922JK';
Select substring(urge_time, 1, 10) From dmr_dev.bxy_overdue_table_with_call_text Group By substring(urge_time, 1, 10);

Select col_date From dmr_c.dmrc_cs_qzm_col_record_union_a_d Group By col_date order by col_date DESC;

Show partitions dmr_c.dmrc_model_t04_collect_overdue_dialogue_i_d;

--anhui分析
Select * From dmr_dev.zym_ccard_label_0706_2jtbt;

Select count(*) From dmr_dev.bxy_temp_pin_list;
Select * From dmr_dev.bxy_temp_pin_list order by rand();


desc dmr_c.dmrc_model_t04_collect_c_score_v3_s_d;
Select * From dmr_c.dmrc_model_t04_collect_c_score_v3_s_d Where dt = '2020-09-01';



Select * From dmr_c.dmrc_model_t04_collect_colrecord_feat_v2_s_d  where dt = '2020-09-08' limit 100;

desc dmr_c.dmrc_cs_qzm_col_record_union_a_d;
Select * From dmr_c.dmrc_cs_qzm_col_record_union_a_d;

desc dmr_c.dmrc_model_t04_collect_c_score_performance_s_d;
Select 
    dt, avg(auc), avg(ks)
From 
    dmr_c.dmrc_model_t04_collect_c_score_performance_s_d
Where 
    dt >= '2020-07-01' and product = 'bt' and phase = '1'
group by 
    dt
order by 
    dt;

Select 
    dt,
    count(*),
    Count(dd),
    count(*) / count(dd) as percentage
From 
    dmr_c.dmrc_model_t04_collect_c_score_performance_s_d
Where 
    dt >= '2020-07-01'
group by 
    dt
order by 
    dt;

use dmr_dev;
drop table if exists dmr_dev.bxy_pin_tmp;
create table dmr_dev.bxy_pin_tmp as
select pin from dmr_c.dmrc_model_t04_collect_c_score_v3_features_s_d where dt='2020-10-27' limit 100;

Select pin, org_score_cuiji From dmr_c.DMRC_MODEL_T04_COLLECT_C_SCORE_V3_S_D Where dt='2020-10-26' and pin in (Select pin From dmr_dev.bxy_pin_tmp) Order By pin;



select count(Case When overdue_days = 1 then 1 else null End) from dmr_c.dmrc_cs_bt_overdays_amt_s_d where pin = 'yihou625838449';

select pin, hist_overdue_cnt, dt
from dmr_c.DMRC_MODEL_T04_COLLECT_BT_CS_ALL_FEATURE_S_D
where pin = 'yihou625838449' and substring(dt, 1, 7) = '2020-11';

select pin, dt, overdue_days
from dmr_c.dmrc_cs_bt_overdays_amt_s_d
where pin = 'yihou625838449' and substring(dt, 1, 4) in ('2018', '2019');


set mapreduce.map.memory.mb=8192; 
set mapreduce.map.java.opts=-Xmx7200m;
select a.dt, a.user_pin as pin, coalesce(b.curoverdays, a.overdue_days) as overdue_days, a.cur_bal
from
(select dt,user_pin,sum(cur_bal) as cur_bal, max(overdue_days) as overdue_days 
    from dmr_bc.dmrbc_cf_bt_loan_s_d
    where user_pin = 'yihou625838449' and dt<'2018-01-01' and consume_status<>'2' and cur_bal>0
    group by dt,user_pin) a
left join (select dt, user_pin, max(coalesce(curoverdays,overdays)) as curoverdays from dmr_bc.dmrbc_cf_bt_bill_detail_s_d
            where user_pin = 'yihou625838449' and dt<'2018-01-01' and sdploanamt>0
        group by dt, user_pin) b
on a.dt=b.dt and a.user_pin=b.user_pin;

select regexp_extract('http://cloyunchu.jd.com/#/login', 'http://[^/]*/[^/]*/([^/]*/?[^/]*)', 1)

select pin,dt,org_score,bt_cur_overdue_days from dmr_c.DMRC_MODEL_T04_COLLECT_C_SCORE_V3_S_D where dt >= '2020-11-25' and pin = '129481518_m';

select * from dmr_c.DMRC_MODEL_T04_COLLECT_BERT_TEXTMODEL_RAW_DATA_I_D where dt = '2020-10-07';
select * from dmr_c.DMRC_MODEL_T04_COLLECT_BERT_TEXTMODEL_RAW_DATA_I_D where dt = '2020-10-06';

select dt, count(*) from dmr_c.DMRC_MODEL_T04_COLLECT_C_SCORE_V3_S_D where dt >= '2020-11-20' group by dt;

select count(distinct user_id) from dmr_dev.bxy_action_sequence_pattern_mining_1;
select count(distinct user_id) from dmr_dev.bxy_action_sequence_pattern_mining_1 where url = 'predictCallPanel';
select count(distinct user_id) from dmr_dev.bxy_action_sequence_pattern_mining_1 where url = 'predictCallQueue';
select count(distinct user_id) from dmr_dev.bxy_action_sequence_pattern_mining_1 where url = 'caseControl';


